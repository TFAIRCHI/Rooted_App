# Product Experience Initiative — October 31, 2026

## Purpose

Explore seven requested improvements as one coherent product direction: richer CoWriter sources, approved social decks, a useful genuine-product homepage demonstration, compact contributor/admin workspaces, a separate visual Studio Creator, simpler member access, and visible approval conversations.

This initiative produces research, proposed contracts/architecture, research-isolated validation, and rendered UX mockup images. **It does not authorize application implementation, source/configuration/package changes, production changes, account connections, paid AI/SMS/video processing, or social posting.** All new artifacts stay in this research folder.

## Perspectives and working method

The four explicitly requested roles are church contributor, UX specialist, data engineer, and church member. These are agent role simulations and expert/heuristic reviews, not interviews or recruited-human usability evidence. The root agent reconciles recommendations and disagreements. Concurrency limits may require role passes and peer review to run in stages; each role has its own assessment.

1. Inspect the current source and prior evidence before labeling a feature present or absent.
2. Verify provider constraints with dated primary documentation.
3. Run narrow existing local tests and research-only synthetic spikes where feasible.
4. Render actual screen mockups, review specific tasks from contributor/member perspectives, and correct concrete issues.
5. Separate recommendation, demonstrated isolated behavior, existing application test, documented provider capability, and untested live integration.
6. Publish a prioritized path, dependencies, acceptance criteria, and unresolved decisions for every requested item.

## Seven workstreams

| # | Requested exploration | Intended outcome |
|---|---|---|
| 1 | DOCX, YouTube URL, website URL, Excel/pasted cells as CoWriter context | Reviewable, traceable teaching sources; no hidden ingestion or unchecked instructions |
| 2 | Contributor/admin creates branded decks; members choose to share | Approved public excerpt assets tied to a study revision, with separate member consent/action |
| 3 | Practical working CoWriter example, possibly video | A truthful source → conversation → confirmed plan → saved draft demonstration that shows value |
| 4 | Less scrolling for contributor/admin | A task-oriented workspace with clear position/state, useful panels, and deliberate reading/preview modes |
| 5 | Separate AI-assisted visual Studio Creator | Reviewed structured media/study blocks, flexible order, consistent immersive member rendering |
| 6 | Phone-oriented member access, church QR routing, later Planning Center | Verified identity with explicit church enrollment rules and durable person/account links |
| 7 | Missing request-changes and response comments | Visible, revision-anchored contributor/approver conversation and resolution trail |

## Research boundaries

- Keep the already completed 35 acceptance checks complete. The local 1.2.15 frontend candidate remains separate from this future initiative; deployment is not part of this work.
- Use fictional church/member/study data. Do not inspect a real Planning Center directory, retrieve secrets, place phone calls, send codes, or post to a social account.
- Treat the current text-based study/approval contract as a real architectural constraint. A visual mockup does not make persisted media, identity linking, or a provider integration work.
- Prefer compact primary views and predictable progressive disclosure. Do not meet a no-scroll target by clipping content, hiding errors, trapping keyboard focus, or shrinking readable text.
- A phone number can be an entry identifier or verified contact method; it is not by itself proof of identity or church membership.
- Sharing is an explicit member action against a separately approved public asset; it must not silently expose a members-only study.

## Evidence labels

| Label | Meaning |
|---|---|
| Current-source verified | Exact source/contract supports the observation; not necessarily a runtime reproduction |
| Existing local test passed | An existing application/component/security test actually ran; its fixture/mocking limits are named |
| Research spike passed | A bounded standalone experiment passed with stated inputs; no application integration is claimed |
| Provider documented | Primary documentation supports a specific capability/constraint, checked October 31 |
| Proposed / conditional | Architecture or UX recommendation needing implementation and defined exit tests |
| Live integration not tested | Account, permissions, provider, device, cost, or production acceptance is still absent |

An item may be recommended with conditional technical feasibility; it is not declared production-ready without the required integration and user checks.

## Preservation evidence

`evidence/application-source-baseline.json` fingerprints application source and primary build files before this research. A final comparison must confirm no changes. Research-only mockup HTML, rendering helpers, fixture files, and images are artifacts, not application code updates.
