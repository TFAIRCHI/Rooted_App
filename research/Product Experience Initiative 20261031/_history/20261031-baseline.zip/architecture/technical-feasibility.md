# Engineering feasibility and proposed architecture

Research date: 2026-10-31, America/New_York. Scope: initiatives 1, 2, 5 and 6. This is a proposal; no migrations, application code, configuration, packages or provider accounts were changed. See [validation](../evidence/engineering-validation.md) for commands, fixtures, primary sources and limits.

## Evidence classifications

| Capability | Current repository evidence | Isolated evidence | Feasibility classification |
|---|---|---|---|
| DOCX context | CoWriter source endpoint accepts TXT only; provider library supports TXT/VTT/SRT | Synthetic paragraphs/table extraction and package boundary rejects pass | Feasible addition; production parser and hostile-file corpus unverified |
| Excel context | No XLSX import contract found | Shared/inline strings, boolean, dates, cached/missing formula values pass | Feasible for selected sheet/range previews; arbitrary workbook semantics unsupported |
| Website context | `ingestion.ts` already implements allowlist, public DNS checks, pinned connection, redirect rejection and bounded reads | Existing mocked transport tests and additional URL boundary checks pass | Feasible extension for public approved hosts; no HTML extraction integration yet |
| YouTube context | No connected caption importer in CoWriter | Official caption API documents OAuth/edit permissions and quota | Conditional on channel access/rights; arbitrary public URL transcript promise unsupported |
| Branded social deck | No deck/rendition schema found | Three synthetic 1080×1350 PNGs exported with installed sharp | Deterministic export feasible; review policy, delivery, browser/device sharing unverified |
| Studio blocks/preview | Current strict content payload is text only | No visual contract or production renderer spike | Feasible staged contract/renderer work; not a CSS-only feature |
| AI images/video | Current CoWriter is text-only, tools empty | No generation provider invoked | Provider/model availability, rights, moderation, latency and cost unverified |
| Phone-first login | Verified OIDC identity; Entra tenant/object mode; no OTP verification auth | Synthetic formatting/household ambiguity only | Requires identity-provider decision; not supported by current External ID SMS first factor |
| QR church routing | Existing `/c/[slug]`, safe auth continuation, invitation acceptance | Source trace only; UX prototype separate | Routing feasible; open enrollment policy/API is additional work |
| Planning Center People link | Existing adapter scope is `publishing`, not `people` | Official People/PhoneNumber documentation only | Future integration requiring explicit People authorization; no live API proof |

## 1. Source ingestion and CoWriter grounding

Extend the existing source/revision foundation. `sources` already has rights/provenance/payload; `revisions.source_snapshot` is included in canonical revision hashing. `cowriter_sources` is actor-private; guided workflow sources are also separate. Preserve those ownership boundaries. A church library source becomes usable in a private conversation through an authorized immutable reference or private snapshot, not by making private imports visible to everyone.

Proposed flow: upload or approved URL → quarantined capture → type/package validation and scan → isolated bounded extraction → visible preview and selection → contributor confirms extracted content and permitted use → immutable source version and spans → bounded context selection → proposal with evidence locators → human adoption using existing revision/version checks.

Proposed records (names illustrative, not migrations):

| Record | Key fields and invariants |
|---|---|
| Source asset | `church_id`, id, owner/scope, original filename/display URL, object key, MIME, original SHA-256, capture time, extraction status; uploaded objects private |
| Source version | Composite tenant key; asset id, extractor/version, normalized content hash, rights purpose/evidence/version, review actor/time, selected sheet/range or URL/caption-track metadata; immutable |
| Source span | Tenant + source-version id + stable locator, normalized text, paragraph/table row/cell or timestamp/cell coordinates; all citations resolve to exact version |
| Request manifest | Base study revision/hash, profile/prompt version, selected source versions/hashes/span ids, truncation/selection metadata, model/usage and output hash |

Original-byte hash and normalized-text hash serve different purposes. Keep both. A changed extraction algorithm or rights purpose creates a new version. A later URL fetch cannot silently replace material used by an approved study. Existing source snapshots should pin source-version/rights/extractor hashes, not only a mutable URL. Rights revocation prevents future generation/export and marks dependent renditions unavailable; do not rewrite the historical approval record.

DOCX: read text in source order with headings and table boundaries; show omitted material. Production implementation needs a maintained parser selected after review, package relationships, tracked-change policy, hyperlinks/footnotes/textboxes handling and tests for malformed/oversized archives. Reject macro-enabled formats, embedded active objects and external relationships initially. No Office execution or conversion service is required for text extraction. File extension/MIME alone are insufficient validation. Quarantine, decompressed-size/member limits, CPU/memory/time limits and disabled external XML entities are required.

XLSX: first show workbook sheets and a contributor-selected table/range, excluding hidden sheets by default. Preserve row/column headings, source cell coordinates, raw/type/style and workbook date system. Show formula expression and stored cached result separately; stale or absent results remain visible uncertainties. Never evaluate formulas, follow external workbook links, execute macros, or infer that all numbers are dates. Exclude unnecessary personal data before AI context. Legacy XLS, XLSM, password protection, pivots, charts-as-data, merged headers, custom date formats and very large workbooks need separate handling/unsupported messages.

Website: retain the existing HTTPS exact-host allowlist, public-address validation of all DNS answers, pinned socket lookup, redirect rejection and read limits. Add a host permission workflow and isolated HTML text extraction without script execution, cookies, authenticated sessions or recursive crawling. Strip active/hidden/navigation content from the extraction preview, retain canonical URL/capture time and source anchors, and let the contributor exclude text. A public page does not establish reuse rights. Requiring an approved final URL is safer and simpler than relaxing redirects; if redirects are later needed, revalidate/pin every hop under strict limits and enforce network egress boundaries.

YouTube: use authorized captions when the signed-in channel account can edit the video and a track is available. `captions.list` returns metadata, not transcript text; list costs 50 units and download 200 units per the checked official docs. Preserve video/track/language/timestamp and machine-caption/translation status; review errors in names and quotations. No scraping/downloading audiovisual content is proposed. If permissions/captions fail, keep the link and ask for an authorized uploaded/pasted transcript. A separate authorized original-media transcription path needs rights, scan/duration, budget and provider tests; its existence in an adapter does not prove the YouTube import path works. [Official caption reference](https://developers.google.com/youtube/data/reference/rest/v3/captions/download), [YouTube policies](https://developers.google.com/youtube/terms/developer-policies).

Current CoWriter checks approximately 10–12 KB of serialized request data depending on action; the reviewed-text upload limit is 256 KiB. Therefore a valid uploaded document can still exceed prompt limits. Selection/chunking and explicit coverage summaries are required. Start with selected spans within existing budgets; retrieval/indexing is a later scale choice, always tenant/scope-filtered before ranking. Extracted content remains untrusted data and cannot grant tools, permissions or publishing authority.

## 2. Branded deck as an approved rendition

Use a deterministic branded template renderer first. Proposed `deck_revision` stores study revision/hash, ordered slide text, asset hashes, source locators, brand/template versions and audience; `deck_rendition` stores renderer/version, format, output dimensions/object hashes and review status. Separate generation job state from immutable approved output. Contributor/admin prepares and previews; an authorized reviewer approves the exact deck hash. Study approval alone does not approve altered or shortened deck language. An approved deck remains unavailable for member sharing until the church enables it for the intended public audience.

Use an explicit capability matrix, not the role label. Current `roleCapabilities.admin` can approve/publish but lacks `content:edit`; the contributor grant differs. To satisfy administrator authoring, deliberately add or assign the proposed deck-authoring capability after policy review; do not infer it from `admin:manage`.

| Proposed operation | Authorization and review boundary |
|---|---|
| Create/edit draft deck | Explicit authoring capability for contributor or administrator; source access and permitted public-excerpt purpose |
| Review/approve exact deck | Explicit deck-review authority; independence/self-approval policy applies to deck author and all approved content/asset hashes |
| Enable member sharing | Explicit public-sharing/publication authority + approved exact rendition + permitted audience; approval alone does not expose draft URLs |
| Withdraw public availability | Explicit public-sharing/publication or designated emergency authority; revoke future fetch/share links, audit reason; downloaded copies cannot be recalled |
| Member share/download | Authorized published public deck only, explicit member choice; no edit, approval, generation or church-wide posting authority |

Current draft edits do not mutate a previously approved source r10 or deck bound to it. Selecting r12/r13 as the deck's new source produces an unapproved rendition; keep old approved availability or withdraw it according to explicit church policy. Never label a deck sourced from the changes-requested current draft as approved. Rights withdrawal is a separate reason to disable existing distribution.

Do not publish private reflection answers, discussions, member names or church directory data. Public export requires its own rights purpose, including Scripture edition/quotation limits and image/logo licenses. Members choose whether to share; opening a reader must never post. Use pre-generated cached assets, not an expensive AI job on member tap. Offer individual PNGs, a downloadable deck package, optional PDF later, and a safe public link only when church policy permits. ZIP/PDF generation was not tested here.

Browser native sharing is progressive enhancement: check `navigator.canShare({files})`, invoke `navigator.share()` during a user gesture in a secure context, and provide Download/Copy link. A resolved share promise is not proof a social post was published. Installed applications, number/order of images and caption handling depend on device/target. No direct social platform publishing API is proposed. [W3C Web Share](https://www.w3.org/TR/web-share/).

## 5. Visual Studio Creator

Keep CoWriter focused on verbal proposals; open a distinct Studio route for composition. Introduce a versioned content payload with ordered, stable-id blocks: text/reference, image, deterministic chart and supported video. Retain a legacy-text renderer and explicit migration path. Do not smuggle visual JSON through `body`, or assume strict v1 contracts accept extra properties. Blocks and order, alt text/captions, asset hashes and presentation settings must participate in canonical revision hashing and approval invalidation.

One shared block renderer should drive the immersive member preview and published reader. It must enforce allowed block schemas/URLs, responsive sizing, reading order, keyboard access, contrast, text alternatives, video controls/captions and reduced-motion behavior. Preview should show a specific unsaved/saved revision state with no editing controls over the reading surface. Permissions and preview authentication must prevent draft leak through public asset URLs.

Current member rendering requires special attention: `frontend/components/member-study-reader.tsx:49` supplies a fallback prayer, `:52` substitutes a literal quotation only for a John 6:68–69 reference match, and `:56`, `:66`–`:71` add fixed introduction/headings to visible and spoken content. Therefore the approved payload alone does not describe every sentence the member sees/hears. Studio must make approved template text/version and licensed Scripture provenance explicit, remove unsupported defaults for arbitrary studies, and test preview/member/audio against the same approved ordered blocks. Reordered JSON alone does not prove delivered order or content parity.

The devotional must remain readable when media is unavailable or disabled. Keep meaningful text/caption alternatives and avoid autoplay or compulsory large downloads. Public deck metadata/analytics must not expose private reactions, completion, discussion or account identity.

AI images/video are asynchronous asset jobs: explicit user action, reserved tenant budget, input/base revision hash, queued/running/succeeded/failed/submission-unknown, moderation/review metadata, immutable asset output and no automatic adoption. Retry/reconcile safely after provider timeouts; never double-submit an unknown paid job. Provider selection is unresolved, including Azure region/model entitlement. Start with deterministic charts and approved/uploaded images; later introduce AI images; defer generated video until real latency/cost/accessibility tests. Charts cite reviewed data and units; AI must not invent numerical series or treat artwork as evidence.

## 6. Member identity, church routing and future People association

Separate three concepts: immutable person/account identity; verified contact method; church membership. Current user ids come from verified OIDC `sub` or `entra:<tenant>:<oid>`, and contributor step-up requires the same user id plus MFA. Phone/name are not identity keys. Current Twilio code sends Messages/status; it does not implement Verify or authenticated account lifecycle.

| Option | Delivery path | Consequence |
|---|---|---|
| A: near-term church QR + current OIDC | QR opens canonical church route; preserve server-validated continuation through existing login; confirm name; explicit enrollment policy/API grants member-only access | Lowest auth migration risk; improves entry immediately but does not fulfill phone-first login |
| B: managed phone-first CIAM using OIDC | Select a provider supporting phone OTP as primary auth and immutable subjects; map issuer+subject to internal principal; add controlled linking to existing identities | Preferred long-term candidate if phone-first is essential; provider/tenant and same-account contributor step-up compatibility must be demonstrated |
| C: Verify-backed authentication service | A dedicated issuer/service handles verification, session/identity lifecycle and OIDC integration, or an explicitly reviewed auth architecture replaces part of the current flow | Highest ownership burden: enrollment, replay, recovery, account linking, abuse, retention and migrations. Verify approval is phone possession, not a complete identity system |

Entra External ID external-tenant documentation checked here explicitly says SMS is a second factor, not a first factor. This is not resolved by enabling an SMS field. Custom federation/bridge compatibility has not been verified in the current tenant; neither provider switch nor bridge is claimed live. [Microsoft External ID MFA](https://learn.microsoft.com/en-us/entra/external-id/customers/how-to-multifactor-authentication-customers), [Twilio Verify](https://www.twilio.com/docs/verify/api).

Model proposal: stable `principal`; `identity_links(principal_id, issuer, subject)` unique per issuer/subject; `phone_contacts` with encrypted E.164 and keyed lookup digest, country choice and verification timestamps; existing tenant-scoped memberships mapped through an audited migration; `join_intents` bound to church/session with expiry; optional `external_person_links` keyed by church + provider organization + person id and reviewed state. A lookup digest must be keyed because phone numbers have low entropy. Avoid exposing whether a phone has an account or directory candidate.

Normalize with an established phone library and explicit country; validate server-side and verify possession. Reject extensions for SMS. Shared phones mean one phone cannot safely identify two independent member accounts. Initial policy should permit a phone credential for one principal only; sharing/recovery conflicts require another credential or support, never a list of private household accounts. A name is not sufficient proof. Recycled numbers require recovery and re-verification policy; mere OTP possession must not silently take over an established account or merge it with an Entra staff account. Maintain stronger contributor/admin authentication; do not downgrade step-up to a member SMS session.

Phone contact capture, login credential verification and optional devotional/marketing SMS consent are distinct records and UI choices. An authentication OTP does not opt the member into future messaging. Preserve purpose, policy version and withdrawal history per church/channel; avoid sending phone numbers or OTPs into AI prompts or analytics.

QR contains canonical church routing data, not an account token or membership role. Authenticate, re-resolve church, show church identity, then transact policy-based member enrollment idempotently. Open / approval-required / invitation-only modes need an explicit schema/policy decision; current invitation-only acceptance must remain distinct. Handle revoked church, stale QR, wrong-account continuation, existing membership and cross-church joins. A printed QR can be copied and is not authorization.

Future Planning Center People association is separate from both Rooted sign-in and church enrollment. Request `people` OAuth permission per church with an appropriately authorized account; retain Publishing independently and handle declined scope/disconnect. Use minimal read-only People/PhoneNumber data to propose candidates; shared/duplicate numbers, names, child/household records and merges require reviewed association, not auto-merge/create. Store organization+person identifiers and verification provenance. Current People reference resolved to API version `2026-10-05`; pin and test a chosen API version. PhoneNumber exposes `e164` and a Person relationship, but the documented query list uses `where[number]`, not `where[e164]`; exact search/normalization strategy needs a real authorized contract test. Respect returned rate headers and `Retry-After`; current docs describe default 100 requests/20 seconds but warn limits can change. [People PhoneNumber](https://api.planningcenteronline.com/docs/apps/people/versions/2026-10-05/vertices/phone_number), [OAuth permissions](https://api.planningcenteronline.com/docs/overview/authentication), [rate limiting](https://api.planningcenteronline.com/docs/overview/rate-limiting).

## Cost and operational planning scenarios

These are scenario inputs, not quotes or forecasts; no provider charges incurred.

| Workload | Illustrative model and controls |
|---|---|
| Phone OTP | US Verify page checked lists $0.05 per success plus $0.0083/SMS attempt. 1,000 successes and 1,200 SMS attempts → $59.96; 10,000 and 12,000 → $599.60, before taxes, other country/carrier/account fees or optional lookup. Failed attempts can still incur channel cost. At 5,000 abuse attempts with no success, SMS component alone would be $41.50 at that input rate. Set global/church/contact/IP limits, resend cooldowns, fraud and spend alerts. [Verify pricing](https://www.twilio.com/en-us/verify/pricing) |
| Deck export | Example: 100 studies × 5 PNGs × 1 MB ≈ 500 MB originals; 1,000 members × five 1 MB slides ≈ 5 GB transfer per study. Cache per rendition and authorization policy; measure actual image sizes and egress rates |
| Text assistance | `requests × (input tokens × input unit rate + output tokens × output unit rate)` plus extraction/storage; current byte checks are not token/cost measurements. Select model/region/deployment before quoting |
| AI images/video | `jobs × variants × provider unit price + retries + moderation + storage + egress`; video duration/resolution multiplies work. Per church quotas and human selection prevent uncontrolled generation. No numerical provider price asserted without a selected provider/model |

## Implementation gates

1. Review-only import/library contract and deterministic deck renderer: hostile/synthetic/representative documents, tenant isolation, permissions, rights-purpose gating, exact rendition approval, revision races, retention and accessible output.
2. Studio v2 contract + shared renderer: legacy compatibility, stable block reorder, draft secrecy, mobile preview parity and approval invalidation.
3. QR + current OIDC enrollment: policy mode, account continuity, member-only grant, idempotency and hostile return URLs.
4. Phone-first ADR/provider selection: tenant proof, identity migration/linking, household/recycled-number recovery, contributor same-account MFA, rate/fraud controls and funded delivery tests.
5. Separately authorize YouTube/People/image/video provider trials only after rights, credentials, scope, costs and retention are resolved. Provider claims remain unverified until those tests happen.
