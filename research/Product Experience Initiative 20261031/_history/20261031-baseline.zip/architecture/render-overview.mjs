import { writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import sharp from 'sharp';
const root = path.dirname(fileURLToPath(import.meta.url));
const escape = value => value.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;');
function box(x,y,w,h,title,lines,color='#fffefa') {
  return `<g><rect x="${x}" y="${y}" width="${w}" height="${h}" rx="12" fill="${color}" stroke="#bccbbc"/><text x="${x+22}" y="${y+35}" font-family="Georgia" font-size="23" fill="#173840">${escape(title)}</text>${lines.map((line,i)=>`<text x="${x+22}" y="${y+65+i*23}" font-family="Arial" font-size="16" fill="#52666b">${escape(line)}</text>`).join('')}</g>`;
}
const arrow=(x1,y1,x2,y2,dash=false)=>`<path d="M${x1} ${y1} L${x2} ${y2}" fill="none" stroke="#216f5e" stroke-width="3" ${dash?'stroke-dasharray="8 7"':''} marker-end="url(#arrow)"/>`;
const label=(x,y,text)=>`<text x="${x}" y="${y}" font-family="Arial" font-size="14" fill="#216f5e">${escape(text)}</text>`;
const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="1800" height="1120" viewBox="0 0 1800 1120" role="img" aria-labelledby="title desc"><title id="title">Rooted proposed product architecture</title><desc id="desc">Reviewed sources and separate verbal CoWriter and visual Studio feed immutable study revisions, visible review and publication. Member reading and approved public decks have distinct audiences. Phone identity and Planning Center People remain gated future integrations.</desc><defs><marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10Z" fill="#216f5e"/></marker></defs><rect width="1800" height="1120" fill="#f7f5ec"/><text x="50" y="55" font-family="Arial" font-size="13" font-weight="bold" letter-spacing="2" fill="#216f5e">ROOTED · PRODUCT EXPERIENCE RESEARCH</text><text x="50" y="105" font-family="Georgia" font-size="39" fill="#173840">One reviewed foundation. Distinct creation and sharing paths.</text><text x="50" y="141" font-family="Arial" font-size="17" fill="#52666b">Logical responsibilities proposed October 31, 2026. Boxes are not new deployed cloud resources.</text>
<rect x="50" y="175" width="1700" height="65" rx="10" fill="#173840"/><text x="75" y="215" font-family="Arial" font-size="18" fill="#fffefa">PRESERVE EXISTING: verified OIDC + church authorization · immutable revisions · exact-hash review · explicit publication · bounded jobs/fetching</text>
<rect x="50" y="270" width="535" height="470" rx="16" fill="#edf0e7"/><rect x="620" y="270" width="540" height="470" rx="16" fill="#edf0e7"/><rect x="1195" y="270" width="555" height="470" rx="16" fill="#edf0e7"/>
${label(75,304,'PRIVATE TEACHING / CREATION')}${label(645,304,'REVIEWED STUDY SNAPSHOT')}${label(1220,304,'READING / SEPARATE PUBLIC EXCERPT')}
${box(75,330,485,110,'Reviewed source versions',['DOCX / text / cells / approved web / authorized captions','Capture → extract → inspect → confirm → pinned spans'])}
${box(75,480,230,155,'CoWriter',['Verbal plan and draft','Selected source evidence','Human confirmation'])}
${box(330,480,230,155,'Studio Creator',['Ordered visual blocks','Asset candidates / jobs','Human selection'])}
${arrow(185,440,185,480)}${arrow(445,440,445,480)}
${box(645,330,490,140,'Versioned study revision',['Text + order + assets + alternatives + template version','Immutable hashes; private draft access; legacy adapter'])}
${box(645,510,490,100,'Visible review conversation',['Actor / time / exact revision / reason / reply','Independent approval, no hidden or implied resolution'])}
${box(645,650,490,65,'Approved publication snapshot',[],'#e3eadf')}
<path d="M305 550 H317 V455 H600 V405 H645" fill="none" stroke="#216f5e" stroke-width="3" marker-end="url(#arrow)"/>${arrow(560,590,645,430)}${arrow(890,470,890,510)}${arrow(890,610,890,650)}
${box(1220,330,505,125,'Shared member renderer',['Preview and reader agree on approved content/order','Optional media; readable alternatives; no draft leak'])}
${box(1220,510,505,125,'Separately approved public deck',['Study hash + deck / brand / renderer / caption / link','Explicit public audience; stale / withdraw policy'])}
${box(1220,675,505,65,'Member reads; sharing stays optional',[],'#e3eadf')}
${arrow(1135,680,1175,680)}${arrow(1175,680,1175,390)}${arrow(1175,390,1220,390)}${arrow(1175,575,1220,575)}<path d="M1725 395 H1738 V707 H1725" fill="none" stroke="#216f5e" stroke-width="3" marker-end="url(#arrow)"/>${arrow(1470,635,1470,675)}
<rect x="50" y="785" width="1700" height="260" rx="16" fill="#e7e2ee"/>${label(75,820,'MEMBER IDENTITY AND ENROLLMENT — PROPOSED INTEGRATIONS ARE GATED')}
${box(75,845,360,145,'Church QR / destination',['Routing context, not authority','Join under church policy','Current verified login can be first'])}
${box(475,845,365,145,'Phone-capable identity',['Provider decision + owned live tests','Verified credential, recovery, limits','Keep staff MFA separate'])}
${box(880,845,390,145,'Stable principal + membership',['Trusted issuer/subject mapping','Phone/name are not account proof','Explicit per-church enrollment policy'])}
${box(1310,845,415,145,'Future Planning Center People',['Separate OAuth scope and permission','Person/phone candidate reconciliation','Directory match is not authentication'])}
${arrow(435,915,475,915)}${arrow(840,915,880,915)}${arrow(1310,925,1270,925,true)}${label(1340,1016,'Dashed: candidate association, never automatic authority')}
<text x="50" y="1090" font-family="Arial" font-size="16" fill="#52666b">Research proof covers named isolated behaviors. Provider integration, durable media, production rendering and real church usability remain future gates.</text></svg>`;
await writeFile(path.join(root,'product-architecture.svg'),svg);
await sharp(Buffer.from(svg)).png().toFile(path.join(root,'product-architecture.png'));
console.log('Rendered product-architecture.svg and product-architecture.png');
