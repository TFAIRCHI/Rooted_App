# Proposed architecture and boundaries

**Research proposal, not deployed architecture.** Read [technical feasibility](technical-feasibility.md) for current-source details, record invariants, permission matrix, provider alternatives and cost scenarios.

![Proposed product architecture](product-architecture.png)

Editable diagram: [SVG](product-architecture.svg), [Mermaid](product-architecture.mmd). The diagram groups logical responsibilities; it does not prescribe a new cloud service for every box.

## Extend these existing foundations

- Verified OIDC sessions, church membership/capabilities, private/public reading separation.
- Reviewed sources/source snapshots, immutable revisions, exact-hash review, explicit publication.
- Existing defended HTTPS fetching: host allowlist, public-address validation, connection pinning, no redirects and bounded reads.
- Existing job/idempotency/accounting patterns and protected tenant data.

## Proposed additions

| Boundary | Responsibility | Critical invariant |
|---|---|---|
| Source capture/extraction | DOCX/XLSX/public page/authorized caption capture, quarantine, bounded extraction | No active document/web execution; reviewable exact content/coverage |
| Source versions/spans | Immutable extracted text and stable paragraph/timestamp/cell locators | Request/approval can identify the precise reviewed evidence |
| Studio content contract | Stable ordered blocks, text alternatives and immutable asset references | Preview and published member reading interpret the same approved content |
| Asset/rendition jobs | Bounded media processing, deterministic rendering, generation candidate provenance | Jobs cannot attach, approve or publish stale/unreviewed results |
| Review history | Protected typed assignment/decision/comment events | Actor/time/revision/hash remain visible across edits; no member/public leak |
| Deck revisions/public rendition | Exact study/deck/brand/renderer/caption/link approval | Public excerpt is intentionally separate from private full study |
| Member identity links | Trusted issuer/subject → stable internal principal; verified contact credentials | Phone/name/People candidate alone cannot select an account or staff role |
| Enrollment policy | Per-church open/approval/invitation join behavior | QR is routing, not authorization; joins are scoped/idempotent |
| Planning Center People sync | Explicitly authorized organization/person mapping | Publishing token/permission does not imply People access or identity proof |

## State and trust boundaries

Keep private source/library scope, draft/media scope, approved study snapshot and public deck audience distinct. Include tenant IDs in relationships and authorization; do not rely only on an unguessable object URL. A changed media block or public rendition needs new approval as defined by its content/audience. Historical approved bytes are not silently mutated by a URL refetch, brand update, template change or regenerated asset.

Member and staff identity remain separate assurance journeys even if they map to the same person. Directory matching is a candidate association, not a trusted authentication event. Login verification, church enrollment, communication consent and public sharing are distinct state transitions.

## Future end-to-end proof

The isolated extraction/export and current review-route tests support parts of the proposal. They do not establish a working new distributed system. A future build must prove source → grounded draft → Studio save → exact review → publication → identical member rendering, then independently prove approved public export and verified church enrollment. Each external provider has its own live ownership/permission/latency/cost/recovery gate.
