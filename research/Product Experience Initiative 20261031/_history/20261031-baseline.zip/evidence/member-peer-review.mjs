import {chromium} from '../../tools/node_modules/playwright-core/index.mjs';
import {writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const output=path.dirname(fileURLToPath(import.meta.url));
const browser=await chromium.launch({channel:'msedge',headless:true});
const page=await browser.newPage({viewport:{width:390,height:844},deviceScaleFactor:1});
page.setDefaultTimeout(5000);
const results=[];
const base='http://127.0.0.1:3091/index.html';
async function visit(query){await page.goto(base+query);await page.waitForLoadState('networkidle');}
const record=(name,result,details)=>results.push({name,result,details});
try{
 await visit('?view=phone&state=ambiguity');
 await page.locator('[data-choose-church="north"]').click();
 await page.getByRole('button',{name:'Continue with selected church'}).click();
 record('Selected church continuity',await page.locator('.church-context').innerText(), 'Select Salem/North, continue, inspect named church context');
 await page.evaluate(()=>window.scrollTo(0,0));
 await page.screenshot({path:path.join(output,'member-review-phone-390.png'),fullPage:true});
 await page.getByRole('button',{name:'Preview phone verification'}).click();
 await page.getByRole('button',{name:'Use the sample code'}).click();
 await page.getByRole('button',{name:'Continue as Riley'}).click();
 record('Optional reminders default',await page.locator('#phone-updates').isChecked(), 'Expected false before explicit opt-in');
 await page.getByRole('button',{name:'Join the reading space'}).click();
 record('Enrollment destination actions',await page.locator('main a').allTextContents(),'Read study should be primary; sharing optional');
 await page.getByRole('link',{name:'Read the study'}).click();
 record('Enrolled reader church',await page.locator('main').innerText(),'Salem/North should survive actual Read study action');
 await page.getByRole('link',{name:'Optional: share a public invitation'}).click();
 record('Sharing gated before member choice',await page.locator('[data-action="share-deck"]').isDisabled(), 'Expected disabled');
 record('Share disclosure',await page.locator('main').innerText(),'Check public excerpt, privacy, downloaded-copy permanence');
 await page.locator('#share-consent').focus();
 await page.keyboard.press('Space');
 await page.locator('[data-action="share-deck"]').focus();
 await page.keyboard.press('Enter');
 record('Explicit share options',await page.locator('#share-options').isVisible(),'Expected true after checkbox + click; no native share invoked');
 await page.evaluate(()=>window.scrollTo(0,0));
 await page.screenshot({path:path.join(output,'member-review-share-390.png'),fullPage:true});
 await page.getByRole('link',{name:/Cancel sharing|Keep reading/}).click();
 record('Return to reading',page.url(),'Must reach reading surface, not sign-in completion');
 record('Return focus',await page.evaluate(()=>({activeId:document.activeElement?.id,scrollY})), 'Expected reflection anchor focus after cancel');
 await page.evaluate(()=>window.scrollTo(0,0));
 await page.screenshot({path:path.join(output,'member-review-reader-390.png'),fullPage:true});
 await visit('?view=preview');
 record('Diagram text equivalent',await page.locator('svg[role="img"] title').allTextContents(),'Informative diagram has readable equivalent');
 for(const width of [320,390,1280]){
  await page.setViewportSize({width,height:844});
  for(const view of ['phone','share','preview','reader']){
   await visit('?view='+view);
   record('Horizontal overflow '+view+' '+width,await page.evaluate(()=>({viewport:innerWidth,scroll:document.documentElement.scrollWidth})), 'Expected scroll <= viewport');
  }
 }
}catch(error){record('Script interruption','error',String(error));process.exitCode=1;}
finally{await writeFile(path.join(output,'member-peer-review-results.json'),JSON.stringify({date:'2026-10-31',kind:'Simulated member task review of research-only static controls; no human participants or live services',results},null,2));await browser.close();}
