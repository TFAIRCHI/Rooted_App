# Engineering validation ledger

Research run: 2026-10-31, America/New_York. Workspace: `C:\Users\tyler\Documents\MyChurch`. Python 3.11.5; Node v24.11.1; existing installed tsx/sharp. All new artifacts are under this research initiative directory. No npm install, package/lockfile edits, migrations, deployment, production modifications, provider API writes, SMS, account creation or external messages. Browsing was read-only official documentation. The repository root has no `.git`; `git status --short` returned “not a git repository,” so a git diff is not available as change-boundary evidence.

## Current-source baseline (read, not assumed from historical research)

| Finding | Current file/line evidence |
|---|---|
| TXT only in contributor CoWriter; 256 KiB upload/text validation; aggregate prompt allowance approximately 10–12 KB | `frontend/components/study-cowriter.tsx:105`; `backend/src/api/cowriter-routes.ts:100`, `:137`; `backend/src/integrations/cowriter.ts` |
| Church source library has TXT/VTT/SRT upload and authorized URL ingestion | `backend/src/api/provider-routes.ts:170`, `:175`; `backend/src/integrations/ingestion.ts` |
| Existing URL validation checks allowlist, all resolved public addresses; request pins validated IP, rejects redirect/compression, caps bytes | `backend/src/integrations/ingestion.ts` (`validateSourceUrl`, `fetchSource`); tested below |
| Existing canonical envelope includes source snapshot and hash | `backend/src/modules/revisions.ts:24`, `:32`, `:38`; `backend/migrations/001_core.sql`; subsequent source snapshot migrations |
| CoWriter sources actor-private under tenant + actor RLS | `backend/migrations/019_study_cowriter.sql`; guided workflow tables in migration 021 |
| Strict content payload has text fields, no typed visual block list | `backend/contracts/payloads.ts:10`; member publication shape in `frontend/lib/member-server.ts` |
| Member reader adds fallback prayer, John-specific quotation and fixed visible/spoken introduction/headings outside saved payload | `frontend/components/member-study-reader.tsx:49`, `:52`, `:56`, `:66`–`:71`; source-reviewed, no runtime parity test performed here |
| Stable verified OIDC identity; Entra tenant/object identity; same-account MFA upgrade | `backend/src/auth/session.ts:17`; `backend/src/auth/routes.ts:126`, `:138`, `:147` |
| Existing join is an identity-bound, expiring invitation | `backend/src/api/onboarding-routes.ts:80` onward; `frontend/components/public/onboarding.tsx:26` |
| Twilio adapter uses Messages/status, not Verify/OTP/session issuance | `backend/src/integrations/twilio.ts` |
| PCO OAuth scope Publishing; read routes exclude People | `backend/src/integrations/planning-center.ts:52`, `:81` |
| Provider status distinguishes configured from live verified | `backend/src/api/provider-routes.ts:155` area (`liveVerified: false`) |

## Completed tests and falsifiable results

Commands from workspace root:

```powershell
python 'research/Product Experience Initiative 20261031/evidence/engineering-spike.py'
node --import tsx 'research/Product Experience Initiative 20261031/evidence/engineering-runtime-spike.ts'
node --import tsx --test backend/tests/integrations/source-fetch.test.ts backend/tests/integrations/security.test.ts
```

| Test group | Actual outcome | What this establishes / does not establish |
|---|---|---|
| Python synthetic spike | Exit 0; **28 checks passed**; named checks/output in [JSON](engineering-spike-results.json) | Narrow stdlib OOXML/identity/hash models; not production parser, RLS or provider proof |
| DOCX fixture | Split runs → `A synthetic sermon`; table cells remain `Theme`, `Hope & service`; closing paragraph stays after table | Basic paragraph/table order and entities; not pagination/layout/Office interoperability |
| XLSX fixture | Shared string Hope, styled serial 40729 → 2011-07-05; C1 retains formula `2+3` and cached 5 with stale-result warning; D1 NOW() remains unknown | Stored values do not require formula execution. Custom styles, arbitrary formulas and recalculation untested |
| Date boundary | 1904 serial 39267 equals 1900 serial 40729; serial 60 marked invalid fictional leap date | Both fixture epochs; no locale/timezone inference validation |
| Package negatives | Path traversal, VBA part, external relationship, DTD/entity declaration and >1 MB expanded input rejected | Explicit negative guards work on these synthetic cases; not comprehensive archive/XML security audit |
| Provenance | Canonical key ordering stable; tenant, extractor or rights changes alter source hash; brand change alters rendition target hash | Proposed manifest identity behavior; not DB immutability or approval implementation |
| Phone model | US/international formatting fixture accepted; missing country, extensions, invalid prefix/short form rejected; one shared phone returns two candidates | Contact normalization/ambiguity demonstration; no global numbering validity, phone ownership, SIM swap or OTP proof |
| Runtime source spike | Exit 0; **21 checks passed**; [JSON](engineering-runtime-results.json) | Actual current URL validation and existing installed renderer; no network/provider access |
| URL negatives | HTTP, credentials, custom port, suffix attack, fragment, decimal/hex loopback and mixed public/private DNS rejected | Specific boundary cases; no external DNS rebinding/TLS/egress penetration test |
| Existing source-fetch/security tests | Exit 0; **8 tests passed, 0 failed** | Current mocked transport pins validated DNS, retains original TLS hostname/default certificate verification, rejects redirect/oversize; transcript parsing, crypto/webhook signatures and Scripture distinctions also pass |
| Deterministic deck export | Three PNGs, each 1080×1350, unique hashes, sizes 70,317 / 71,428 / 72,143 bytes; slide 1 visually inspected | Installed sharp can render synthetic template. No brand policy, overflow corpus, browser-share, PDF/ZIP, social target, accessibility or approval-flow proof |

Artifacts: [DOCX fixture](synthetic-fixtures/sermon-notes.docx), [XLSX fixture](synthetic-fixtures/study-context.xlsx), [deck slide 1](synthetic-deck-1.png), [slide 2](synthetic-deck-2.png), [slide 3](synthetic-deck-3.png), [Python source](engineering-spike.py), [runtime source](engineering-runtime-spike.ts).

The synthetic OOXML fixtures are deliberately minimal zipped XML packages rather than Office-authored documents with full OPC content types/relationships. Fixed filenames and a limited style subset are used. This makes the extraction assertions reproducible but does not prove a general document parser. No macros, formulas, JS or external relations were executed. No files were extracted to arbitrary filesystem paths.

Two initial Node invocations failed before execution because workspace dependencies were hoisted rather than at guessed backend-local paths: missing `backend/node_modules/tsx/dist/loader.mjs`, then missing backend-local sharp. The research script was corrected to `node --import tsx` and package import `sharp`; final invocation passed without installing anything. No failed provider attempt is hidden behind those results.

## Primary-source evidence checked before recommendations

All below accessed during the 2026-10-31 research session (local date). A listed document update date is the page's reported date, not a claim about provider rollout to this tenant. “Not stated/checked” means no exact publication date was established.

| Source | Reported date/version | Decision supported |
|---|---|---|
| [YouTube captions download](https://developers.google.com/youtube/data/reference/rest/v3/captions/download) | Last updated 2026-10-15 UTC | Video edit permission and OAuth needed; 200-unit download; cannot promise every public URL |
| [YouTube captions list](https://developers.google.com/youtube/data/reference/rest/v3/captions/list) | Last updated 2026-10-15 UTC | Metadata only, 50-unit list operation; separate caption retrieval |
| [YouTube developer policies](https://developers.google.com/youtube/terms/developer-policies) | Last updated 2026-10-15 UTC | Section III.E.1 restricts audiovisual downloading/caching without prior written approval; reuse/privacy/deletion obligations need review |
| [Microsoft External ID MFA](https://learn.microsoft.com/en-us/entra/external-id/customers/how-to-multifactor-authentication-customers) | Last updated 2026-05-28 | External tenants support SMS as second factor; not primary phone auth. SMS requires subscription/add-on |
| [Microsoft Word table structure](https://learn.microsoft.com/en-us/office/open-xml/word/how-to-insert-a-table-into-a-word-processing-document) | Last updated 2025-01-21 | Paragraph/table/row/cell structure used by synthetic extraction |
| [Microsoft spreadsheet formulas](https://learn.microsoft.com/en-us/office/open-xml/spreadsheet/working-with-formulas) | Last updated 2025-01-14 | Formula `<f>` and cached `<v>` differ; stored result may be absent/stale |
| [Microsoft Excel date systems](https://support.microsoft.com/en-us/excel/date-systems-in-excel) | Update date not stated/checked | 1900 and 1904 systems differ by 1,462 days; preserve workbook epoch |
| [OWASP SSRF prevention](https://cheatsheetseries.owasp.org/cheatsheets/Server_Side_Request_Forgery_Prevention_Cheat_Sheet.html) | Living source; date not stated/checked | Allowlist/IP validation and redirect prevention; retain existing controls and network isolation |
| [OWASP file upload](https://cheatsheetseries.owasp.org/cheatsheets/File_Upload_Cheat_Sheet.html) | Living source; date not stated/checked | Extension/type validation alone insufficient; quarantine/limits/scan/isolation proposal |
| [W3C Web Share](https://www.w3.org/TR/web-share/) | Recommendation 2023-05-30 | Sharing depends on user agent/OS; files, transient activation and capability checks. Not direct publishing proof |
| [Twilio Verify API](https://www.twilio.com/docs/verify/api), [verification resource](https://www.twilio.com/docs/verify/api/verification) | Update date not stated/checked | E.164 and verification/check lifecycle; current Messages adapter is a different capability |
| [Twilio Verify best practices](https://www.twilio.com/docs/verify/developer-best-practices) | Update date not stated/checked | International handling, retries, recovery and separation of verification/authentication |
| [Twilio Verify pricing](https://www.twilio.com/en-us/verify/pricing) | Dynamic page; no quote validity period | US planning inputs $0.05/success + $0.0083/SMS; channel attempts may be billable without success; regional/account fees vary |
| [Planning Center auth](https://api.planningcenteronline.com/docs/overview/authentication) | Update date not stated/checked | Product scopes distinct; user permissions constrain API access; OAuth required for multiple churches |
| [PCO People reference](https://api.planningcenteronline.com/docs/apps/people/versions/2026-10-05), [PhoneNumber](https://api.planningcenteronline.com/docs/apps/people/versions/2026-10-05/vertices/phone_number), [Person](https://api.planningcenteronline.com/docs/apps/people/versions/2026-10-05/vertices/person) | Version 2026-10-05 (current docs link resolved here) | E.164 + person relation, documented `where[number]`, organization-specific association; do not assume `where[e164]` exists |
| [PCO rate limits](https://api.planningcenteronline.com/docs/overview/rate-limiting) | Living source; date not stated/checked | Default 100/20s per user, limits dynamic; obey response headers/Retry-After |

`developer.planning.center/docs` initially returned a JavaScript-only shell; following official API documentation links reached the readable `api.planningcenteronline.com/docs` sources above. No unofficial API transcript package, phone-auth workaround or speculative People search endpoint was used as evidence.

## Missing proof and release gates

- **Documents:** real DOCX/XLSX producer/version corpus; standards-complete package traversal; encrypted/large/malformed archives; nested/merged cells; custom styles/date/time; redaction; parser dependency/license/security review; malware scan and resource containment.
- **Website:** production egress rules, live approved-host DNS/TLS/redirect/compression behavior, canonical extraction quality and source rights; authenticated/dynamic/paywalled pages remain unsupported initially.
- **YouTube:** OAuth client approval/consent, target church edit permission, track availability/languages/automatic-caption accuracy, quota exhaustion, token revocation, retention/deletion obligations and rights. No audiovisual download/transcription tested.
- **Deck/Studio:** exact revision/rendition approval, stale asset/brand invalidation, tenant/draft leakage, public export consent/rights, keyboard/reduced-motion/mobile behavior, media-disabled reading, image/video provider entitlement/quality/moderation, timeouts/unknown submission and funded cost tests.
- **Phone:** provider choice and target tenant entitlement, real delivery/country/retry/expiry/replay/fraud/fees, recovery, recycled/shared phone policy, authenticated identity linking, migrated member history, contributor same-account MFA and session revocation. No SMS sent, and no proof that entering a name/phone establishes person identity.
- **QR/enrollment:** real mobile scan/continuation, stale/wrong/multiple church links, existing account/membership, policy modes, grant idempotency and role escalation tests.
- **People:** authorized church OAuth `people` scope, actual current user permissions/API version/query behavior/pagination, duplicate/shared/child/household candidates, merged/deleted records, disconnect/revocation and rate handling. No directory data fetched or written.

Feasibility language in the engineering proposal distinguishes repository-supported facts, documentation-supported capability, isolated-spike-tested behavior and provider-unverified dependencies. None should be read as live integration validation.
