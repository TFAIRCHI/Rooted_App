# Contributor and administrator assessment

Research date: 2026-10-31. This is a simulated church contributor/administrator role assessment based on repository evidence, not interviews, church observation, or a production usability study. Application code, packages, configuration, deployment, and production data were not changed.

## Recommendation

Make the smallest complete editorial loop dependable first: choose a study date, add and review context, draft words, prepare optional visuals, send to another authorized reviewer, read the reviewer's changes, revise, approve, and publish. A volunteer must be able to resume this loop next week without reconstructing the state from memory. Repair note visibility before expanding creation features; otherwise more content increases the volume of work that gets stuck.

Suggested order: (7) review conversation; (4) compact task workspace and truthful save states; (1) DOCX ingestion followed by website/YouTube/Excel adapters; (3) recorded working CoWriter demonstration; (5) persistent visual blocks and preview; (2) approved share decks built on that asset foundation; (6) member phone onboarding can progress independently with identity engineering. These are dependency and contributor-value priorities, not estimated delivery dates. All seven remain in scope; the order does not defer investigation of any requested input type.

## What the contributor actually has today

- A date-first study workspace with an expandable week list, calendar alternative, selected-date settings, lifecycle controls, and a three-step Create Study / Gain Approval / Publish Study workflow. See [studies.tsx](../../../frontend/components/studies.tsx:33), [unified-plan-editor.tsx](../../../frontend/components/unified-plan-editor.tsx:42).
- An autosaving text draft, current member phone preview, revision comparison and comments, a floating per-study CoWriter, and a separate guided CoWriter for planning multiple days. See [content-editor.tsx](../../../frontend/components/content-editor.tsx:316), [content-editor-with-preview.tsx](../../../frontend/components/content-editor-with-preview.tsx:11), [guided-study-cowriter.tsx](../../../frontend/components/guided-study-cowriter.tsx:17).
- Reviewer selection and submission notes, exact-revision approval, and requested-changes decisions. The note path is incomplete for readers; see [item 7](../items/07-approval-conversation.md).
- Church name and theme exist. Rooted is the platform identity and the church supplies its name/brand; this is a useful foundation for future deck templates. See [account-requests.tsx](../../../frontend/components/account-requests.tsx:18), [core-routes.ts](../../../backend/src/api/core-routes.ts:41).
- Authorization is capability-based. An administrator can have approve/publish permissions without content authoring permissions; the existing browser test explicitly checks this. Do not assume the word “admin” means the user can create or edit every artifact. See [onboarding-routes.ts](../../../backend/src/api/onboarding-routes.ts:22), [admin-review.spec.ts](../../../frontend/e2e/admin-review.spec.ts:18).

## Seven requested improvements

### 1. Context: DOCX, YouTube, website, and Excel

Current proof: both CoWriter surfaces accept pasted text or one UTF-8 `.txt` file, capped at 256 KiB. Guided CoWriter can choose an already reviewed library source. The per-study server explicitly rejects non-`.txt` filenames. See [study-cowriter.tsx](../../../frontend/components/study-cowriter.tsx:103), [guided-study-cowriter.tsx](../../../frontend/components/guided-study-cowriter.tsx:94), [cowriter-routes.ts](../../../backend/src/api/cowriter-routes.ts:100). Adding a YouTube link through the study body toolbar currently creates a link in text; that is not extraction of source context.

Minimal successful path: one Sources panel accepts drop, file picker, or URL; identifies type; extracts to a readable preview; lets the contributor select evidence and confirm its use; then makes reviewed evidence available to both CoWriter surfaces. Existing text paths remain the fallback. Build four input-specific previews rather than pretending all inputs are prose:

| Input | Required author decision | Smallest honest outcome | Tradeoff |
| --- | --- | --- | --- |
| DOCX | Confirm headings, paragraphs and tables extracted as intended | Drag or pick `.docx`, inspect text/table preview, confirm selected content | Complex layouts, comments and embedded images can be unsupported if the preview identifies omissions |
| YouTube URL | Select available transcript and relevant time range | Transcript with language/time references, then reviewed context | Unavailable transcripts require pasted/uploaded transcript; never show “added” as if video was understood |
| Website URL | Inspect extracted article vs navigation/boilerplate | Title, source URL, capture time, selected article text | Authenticated/dynamic pages may fail; do not ask volunteer to debug fetch infrastructure |
| Excel | Choose workbook sheet, header and range | Table preview with sheet/range and exact values used | Preserve units, dates, percentages and formulas versus cached values explicitly; never silently flatten the entire workbook |

Acceptance proposal: a representative fixture for each type imports without manual conversion, a partial/failed extraction is actionable, and confirmed evidence remains attached after reload. Cancel before confirmation produces no generation. Each generated proposal can identify its reviewed source/version. A revised file/URL capture requires a fresh review. Verify keyboard access to the file picker as well as drag/drop. Before estimating speed, measure extraction on agreed fixture sizes and establish limits visibly.

Contributor value: sermon preparation usually lives outside Rooted. Reducing conversion work is useful only if the contributor can see what the assistant actually received. A polished drop zone without extraction, review, provenance and recovery does not meet the request.

### 2. Church + Rooted share decks linked to a study

Current proof: no dedicated deck or member deck-sharing workflow was found in the reviewed source. Existing content schema is text fields plus references, not slides. See [contracts.ts](../../../frontend/lib/generated/contracts.ts:5). Church identity/theme can supply a baseline brand but is not a deck engine.

Minimal successful path: a contributor with artifact-authoring permission chooses one approved study revision, selects a quote, a Scripture card, and an image/chart card, adjusts a small set of approved layouts, previews church + Rooted branding, and submits the deck for approval. An administrator with review authority can approve; authoring still requires explicit permissions. Publish an immutable approved deck attached to that study. A member sees “Share this study” only for approved/published material and chooses whether to share/download. No automatic posting and no requirement to share in order to read.

Acceptance proposal: three card types export at an agreed social format without clipped text; source study and revision are recorded; church name and Rooted attribution appear correctly; Scripture includes reference and applicable translation attribution; every chart has a data source/units and accessible description; a changed study marks old derived decks stale. A member can cancel sharing without creating a post. Withdrawal removes the in-app share action and resolves old share links to the agreed withdrawn state; externally downloaded copies cannot be recalled.

Tradeoff: start with a constrained template set and image downloads, then add editable decks/PDF or social destinations if validated. A deck is a distinct approval artifact: study approval alone does not prove that a shortened quote, crop, chart or slide arrangement is accurate. An AI chart must be grounded in selected data and must not invent numbers to decorate a teaching point.

### 3. Convincing working homepage demonstration

Current proof: the homepage has an illustrated sermon-to-phone story. `/ai-co-writer` embeds `CowriterExample`, which switches between hard-coded prompts and responses and calls itself an illustrative conversation. See [marketing-pages.tsx](../../../frontend/components/public/marketing-pages.tsx:16), [marketing-interactions.tsx](../../../frontend/components/public/marketing-interactions.tsx:82). This is useful explanation but not evidence of a working request.

Minimal successful path: record a real isolated CoWriter session using fictional church-owned source material: confirm context, ask a specific request, see clarification, change the direction, confirm one day's creation, edit its saved draft, then show independent review. Put an explicit “Watch CoWriter work” action on the homepage, with a short captioned video and optional chapter links. Show a real saved/reloaded draft rather than ending on generated text. Existing capabilities should be demonstrated now; planned DOCX/Studio/deck features must not appear as live until implemented.

Acceptance proposal: the recording has no member information or secrets; clearly identifies a fictional sample; shows at least one human correction and its effect; captions/transcript match the recording; controls work on mobile/keyboard; no paid generation occurs on page load. Proposed length: 60–120 seconds plus optional longer walkthrough. Validate comprehension with real church staff later: can they say what they must provide and what still needs their review?

Tradeoff: a recording is reproducible and cheap to serve. A live public sandbox needs its own cost, latency, abuse and failure design. Do not call scripted selections a working live assistant. This research did not invoke an AI provider or record a session.

### 4. Less scrolling for contributors and administrators

Current proof: the selected study appears below week/calendar controls and other settings. `ContentEditor` hides its writing surface outside workflow step 0, but review-assignment and publication sections have separate render paths, and history can add another full panel. See [studies.tsx](../../../frontend/components/studies.tsx:85), [content-editor.tsx](../../../frontend/components/content-editor.tsx:426), [content-editor.tsx](../../../frontend/components/content-editor.tsx:670), [content-editor.tsx](../../../frontend/components/content-editor.tsx:799). The implementation already has progressive disclosure; the gap is orchestration and discoverability, not the complete absence of steps.

Minimal successful path: use a compact selected-study header with church/date/save state, a short task switcher, and one main task panel. A date rail or drawer replaces the full calendar above every edit. Sources, CoWriter, Studio Creator, Share deck, and Review can be task choices; Publish can be an explicit gated action in Review. Keep “Changes requested” and a link to the note visible across tasks. Administrators should land on their assigned review queue and preview, while authors land on their draft task.

Acceptance proposal: at 1366×768 the title/date, task choices, saved state and primary action appear without page scrolling; at 390px wide all tasks are discoverable without horizontal page overflow; keyboard movement/focus works; changing task/date cannot silently discard unsaved text or local assets; switching church clears prior church context. Complete source → edit → review-note lookup tasks with fewer full-page scrolls than the current baseline. Measure the baseline before setting a numeric reduction target; proposed usability target is at least 50% fewer full-page scrolls for those tasks.

Tradeoff: tabs can conceal essential state and increase back-and-forth. Preserve draft state, task URL/deep links and last position; use drawers for optional context, not for the primary unresolved review message. Avoid nested tabs in a small viewport.

### 5. Separate visual Studio Creator

Current proof: `StudyComposer` edits a text body, inserts Markdown-like hosted image/video links, and offers browser-only local media previews. Those local files are not uploaded or saved. The published member reader splits the body into paragraphs; the phone preview renders it as plain text. See [study-composer.tsx](../../../frontend/components/study-composer.tsx:90), [study-composer.tsx](../../../frontend/components/study-composer.tsx:125), [study-composer.tsx](../../../frontend/components/study-composer.tsx:245), [member-study-reader.tsx](../../../frontend/components/member-study-reader.tsx:44), [member-phone-preview.tsx](../../../frontend/components/member-phone-preview.tsx:40). Existing toolbar affordances do not prove that a visual survives publication.

Minimal successful path: verbal CoWriter remains responsible for words, questions and teaching direction. Studio opens on the same study revision but works with typed text/image/chart/video blocks. A contributor can add or generate an asset, inspect it, position it, reorder blocks through drag or Move up/down, provide alt text/captions, and see an immersive preview using the member renderer. Preserve the original wording while allowing a visible suggestion back to CoWriter if wording changes are needed. Label upload/generation progress and failures accurately.

Acceptance proposal: insert one image, one data-grounded chart and one approved hosted video; reorder with pointer and keyboard; save, reload, approve, publish, and verify identical order/content in the member experience. Failed media processing retains the original saved study and gives retry/remove. Text remains readable with media disabled. Preview does not count as member engagement. Every edit invalidates the approval for the exact artifact that changed. Generated media provenance, moderation, storage and quotas are engineering prerequisites.

Tradeoff: typed blocks require a content contract/version migration and a shared renderer. A visually attractive editor without persisted media, published parity and approval semantics would repeat the existing local-preview limitation. Start with still image/chart/video embedding; full AI video generation has larger cost/latency and review requirements and should follow separately.

### 6. Phone-number member sign-in, QR routing and future Planning Center link

Current proof: member sign-in copy says email; authentication delegates to OIDC, with contributor access re-verification separated from reading access. Church-link discovery accepts a same-origin `/c/slug`; enrollment uses named invitations. Phone fields found in provider migrations are messaging-related, not proof of phone login. Planning Center is reported disabled in workspace data. See [sign-in.tsx](../../../frontend/components/public/sign-in.tsx:36), [auth/routes.ts](../../../backend/src/auth/routes.ts:83), [find-church.tsx](../../../frontend/components/public/find-church.tsx:6), [onboarding-routes.ts](../../../backend/src/api/onboarding-routes.ts:80), [core-routes.ts](../../../backend/src/api/core-routes.ts:93).

Contributor/admin minimal successful path: administrator creates a church-specific member QR/link; member scans, sees church identity, verifies a phone number, supplies a preferred name, and confirms joining that displayed church. If already verified, route directly to that church and idempotently ensure member enrollment under the church's join policy. The QR chooses church context; possession of the QR must never grant contributor/admin privileges. Keep stronger team verification distinct. Treat a future Planning Center person ID as an external identity association with a reviewable match, not as the account's primary key.

Acceptance proposal: new and returning members arrive at the scanned church, including when they belong to more than one; repeated scans do not duplicate membership; incorrect/expired verification codes recover; a changed/recycled phone has an account recovery path; a staff account scanning a member QR gains no additional team permissions. Name changes do not break the account or external person link. Joining does not itself enable outreach. No Planning Center sync is claimed before connection, mapping and conflict handling exist.

Tradeoff: QR routing is relatively independent from phone authentication. Phone verification requires a real configured identity/verification provider and operational handling for delivery, cost, number changes and recovery. Automatic low-privilege membership needs an explicit church join policy. Avoid making volunteers manually invite every public QR visitor, while giving restricted churches a closed option. Validate ministry-specific household/shared-number cases with actual churches before enforcing one-number/one-person assumptions.

### 7. Make approval notes visible and actionable

Current proof: submission notes and review decisions are stored in separate tables. The submission note is already returned to the frontend but unused; the decision reason lacks an ordinary editorial read path. Existing comments are a third stream and do not automatically contain decision notes. See [detailed trace and acceptance plan](../items/07-approval-conversation.md).

Minimal successful path: render the latest assignment note to the approver; render requested changes to the contributor immediately and after reload; attach both to actor/time/revision and keep earlier cycles accessible after edits. Add a reply/comment and resubmit path without redefining approval as a casual chat action.

Acceptance proposal: two real isolated browser sessions complete submit(note) → request changes(reason) → contributor reload → edit/reply → resubmit → approver reload → approve; every note is readable by its intended role and absent from member/public routes. Empty change reasons fail; stale decisions fail; cross-church and unassigned-contributor reads fail. A dedicated real API/database harness now confirms stored notes, missing author-facing decision reason, and the same-revision resubmission defect; the exact browser roundtrip remains pending.

## Verification performed and limits

Ran `npm exec --workspace=@gather/frontend -- vitest run components/content-editor.test.tsx components/study-composer.test.tsx components/studies.test.tsx`: **3 files, 13 tests passed** (8.02 seconds reported). These existing tests use local components and mocked network calls. They exercise save draining/submission, preview updates, hosted-link insertion, and study navigation; they do not verify note persistence/rendering, phone login, source conversion or Studio/deck publication.

Read `frontend/e2e/admin-review.spec.ts` and `backend/tests/integration/editorial.test.ts`; did not run those suites. The browser test covers independent approval. Subsequently ran the dedicated [approval harness](../evidence/approval-roundtrip.ts) against current API source, one uniquely owned disposable loopback database and local OIDC. [Runtime results](../evidence/approval-roundtrip.json) confirm stored assignment/decision notes, missing decision reason in author DTOs, same-revision resubmit 409/23505, valid new-revision resubmit/approval, and selected invalid-input/access guards. API/OIDC closed and owned database drop/absence verified. No production or paid provider call, installation or application change occurred. No real church users participated. Proposed acceptance criteria and time/scroll targets are design recommendations, not measured results.

## Peer review: engineering and rendered UX

Reviewed [engineering feasibility](../architecture/technical-feasibility.md) and [engineer assessment](data-engineer-assessment.md). The source-version/selected-span design, separate AI-use versus public-export rights, exact deck rendition hash and explicit immutable-principal identity model fit contributor needs. Add an explicit permission matrix before implementation: deck create/edit, deck review, member-share enablement and withdraw are distinct actions; current admin role is allowed to approve/publish but is not automatically a text author. Do not infer these grants merely from “contributor/admin” product labels. Preserve independent review and show when an old approved study rather than the current draft supplies a deck.

For sources, expose selected coverage and version in human terms (“sheet/range”, “transcript time range”, “selected excerpt”) and keep private CoWriter imports private. Extraction-ready, confirmed for AI and licensed for public deck reuse are three different states. Rights/source/template changes should invalidate future use and exact approvals, while old review history remains legible.

Visually inspected actual rendered captures [Word source](../mockups/captures/02-source-word-review.png), [deck approval](../mockups/captures/10-deck-approval.png), and [review conversation](../mockups/captures/17-review-conversation.png). These are static fictional research concepts, not live feature verification. The pinned unresolved request, exact old/current revision comparison and explicit “reply does not resolve” behavior address the main contributor failure. Sent three required revisions to UX:

1. Deck approval screen must identify an approved source study revision and block approval from the current unapproved revision; the viewed screen showed study r12 while the persistent context still indicated requested changes/current draft.
2. Source reviewed counts must match tray state: the viewed screen said “2 sources reviewed” while one of two was still awaiting review. Show confirmed/included versus pending separately.
3. Compact the working header/callout/task navigation. At desktop 768px height, substantive task content began around 500px down, leaving too little room for source/deck/review work. A concept can reduce page length yet still require excessive scrolling for its primary action.

The [final contributor peer review](contributor-peer-review.md) inspects the corrected desktop captures and marks all three original visual findings resolved in the concept. A final recheck also confirms the corrected hypothetical stale-source label. Real church usability remains untested. Engineering peer review does not validate external provider contracts or phone-delivery/recovery behavior; retain those explicit integration gates.

## Questions for actual church validation

Which source types appear weekly, and what must survive extraction? Who approves image/chart/quote meaning as well as study words? Does the team think in a week or one date? Which tasks are done on phones? Are members likely to share a whole deck or one card? How are households with shared phones and visitors handled? These questions should be tested with church contributors, reviewers and members; role simulation cannot establish their answers.
