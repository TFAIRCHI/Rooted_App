# Contributor peer review: final research concepts and feasibility

Reviewed 2026-10-31 America/New_York. This is a simulated contributor/administrator review, not human church research. The review below is based on the actual rendered PNGs opened with the image tool. No application code or production data was changed, and no additional application tests were run for this visual pass.

## Final verdict

**Proceed with a concrete item 7 repair and staged planning for the future concepts.** The missing review conversation is now supported by current-source tracing and a real isolated API/database reproduction. It is sufficiently understood for an implementation brief: expose authorized revision-scoped assignment/decision history, render both note directions, retain prior requests after edits, and define same-revision resubmission behavior. The repair is not implemented by this research.

The future Sources, Studio, deck and member-entry concepts are coherent enough to guide scoped prototypes, contract work and provider decisions. Their rendered interactions are research simulations. They do not prove DOCX/YouTube/website/Excel production ingestion, media persistence, AI generation, deck approval/delivery, phone authentication or Planning Center integration. Retain the engineering validation gates and conduct actual church usability research before making claims about contributor efficiency or member preference.

## Actual images inspected in this final pass

| Capture | Observed detail | Judgment |
| --- | --- | --- |
| [35 · compact source first view](../mockups/captures/35-compact-source-first-view.png) | At 1366×768, church/date/revision/save state, unresolved request, task switcher, source preview and consent/confirm action rail are visible. Counter now reads “1 included · 1 awaiting review”; selected excerpt is paragraphs 1–4. Confirm is visibly disabled before the unchecked review consent. | Original source-count and first-viewport action findings resolved in the concept. Image inspection alone does not verify disabled behavior or full keyboard access. |
| [36 · compact Studio first view](../mockups/captures/36-compact-studio-first-view.png) | Distinct Studio task, block list, selected diagram, visual description, Move up/down and Immersive preview are visible at 1366×768. Action rail identifies saved study r12 and visual-layout draft, with “no new asset has been created.” | Original main-action scrolling finding resolved for this desktop state. Full selected-block options still need scrolling, which is acceptable; media persistence and published preview parity remain implementation requirements. |
| [37 · compact review first view](../mockups/captures/37-compact-review-first-view.png) | Pinned requested change remains visible; open request labels revision 11, current draft labels revision 12. Reply entry and simulated resubmit r12 are available in the bottom action rail at 1366×768. | Original review-action scrolling finding resolved. The review preserves old/current revision meaning and makes the next action discoverable. A screenshot cannot prove successful reply persistence or resubmission. |
| [10 · deck approval](../mockups/captures/10-deck-approval.png) | “Approver preview” and the review callout explicitly identify approved source study r10, not current draft r12. Deck v2 includes four card images, caption and public destination, with approval specific to that rendition. The persistent editor context continues to show r12/changes requested. | Original unapproved-source approval ambiguity resolved. Current draft r12 and separately approved deck source r10 remain distinct. The approver preview must remain an explicit scenario/permission boundary in implementation. |
| [11 · deck stale](../mockups/captures/11-deck-stale.png) | Deck is “Out of date”; card states that a changed source makes the rendition stale and pauses new export/member sharing pending approval. Its original approved source is r10. After a final recapture, the card explicitly says “Preview case: selecting revision 13 as the new source,” while the current editor stays on r12. | Stale-state intent is clear. The final label resolves the small additional scenario inconsistency; the hypothetical source change is distinguished from the actual current editor revision. |

The original three findings are **resolved in the final viewed desktop concepts**: misleading reviewed-source count; deck approval appearing tied to an unapproved current revision; and primary source/Studio/review actions falling below a 768px first viewport. A final image recheck also confirms the stale-scenario wording correction. Remaining limits are untouched mobile/keyboard behavior in this pass and the difference between a simulated control and a working authorized feature.

## Current API evidence that should drive implementation

The earlier [approval harness](../evidence/approval-roundtrip.ts) ran against the current backend source with real local OIDC accounts and exactly one owned disposable PostgreSQL database. [JSON evidence](../evidence/approval-roundtrip.json) records the results and verified teardown. It confirmed:

- Contributor assignment note and administrator request-changes reason both persist against the submitted revision.
- Author aggregate GET is 200 without either note; latest review-request GET is 200 with the contributor note but without the administrator reason; comments GET is 200 with an empty array. Frontend source separately confirms the returned assignment note is not rendered.
- Same-revision resubmit produces **409 / 23505**. The failed transaction preserves the original note/status. Saving a changed revision produces 201, resubmission 200, and independent approval 201; the original reason remains in stored history.
- Empty change reason returns 422; wrong hash 409; stale version 412; member internal reads 403; cross-church author read 404.

These are actual current-API/database findings, not mocked storyboard behavior. They do not prove production incident data or browser rendering. API/OIDC closed, the owned database was dropped, and its absence was verified. Existing frontend component verification earlier passed 13 tests across three files; no extra app tests were run for the final image pass.

The new conversation should not promise that a reply alone permits same-revision resubmission. Choose and explain either an explicit new revision or repeated request cycles against one revision. Preserve exact-revision/hash approval and do not let a “resolved” chat action substitute for the independent approver's decision.

## Engineering cross-review and minimum delivery boundaries

[Engineering feasibility](../architecture/technical-feasibility.md) appropriately extends immutable source versions/spans, existing provenance hashes, strict content-versioning and exact approved deck renditions. Preserve these contributor-facing consequences:

1. Sources must distinguish extraction preview, included reviewed evidence and public-export rights. Show selected coverage in human terms and preserve private conversation ownership. A parser spike is not arbitrary Office/URL compatibility.
2. Deck permission design needs explicit create/edit, independent review, member-share enablement and withdrawal actions. Current administrator approval/publishing grants do not imply text authoring. A deck can deliberately cite approved r10 while the contributor edits r12, but the UI must state that relationship, as the corrected approver image now does.
3. Studio needs a strict versioned block contract and the actual member renderer for saved/reloaded/published output. All visible/spoken template text and Scripture provenance must be inside the approval boundary. Local preview cards cannot establish persistent media or member/audio parity.
4. Phone-first login remains an identity/provider decision with account continuity/recovery work. QR routing and church enrollment can advance independently but are only partial delivery of the phone-first request. Planning Center People association remains a separate integration.

No feasibility approval here authorizes application implementation, deployment, paid-provider trials or production data work. The research delivers a concrete repair direction and future acceptance boundaries for Tyler to review.
