# Data engineer assessment

Research-only assessment, 2026-10-31. My decision is **proceed with staged implementation planning**, while retaining explicit integration gates. None of the seven requested improvements is implemented by this research. Primary ownership here is initiatives 1, 2, 5 and 6; UX and contributor findings supply the other workstreams.

The useful existing foundations are tenant-scoped sources with rights/provenance; canonical revision/source snapshot hashing; actor-private CoWriter conversations; capability-based editorial approval; OIDC identity verification and same-account contributor MFA; a bounded URL fetcher with exact host allowlisting, public DNS checks, pinned socket lookup and redirect rejection. Preserve them.

The material gaps are not cosmetic. CoWriter accepts one reviewed TXT source and uses a roughly 10–12 KB serialized prompt allowance; provider sources support TXT/VTT/SRT but not DOCX/XLSX/HTML/YouTube captions. Content payload v1 is strict text-only. Twilio is outbound messaging, not phone authentication. Planning Center is Publishing scope and Publishing route allowlist, not People access. Joining currently accepts an identity-bound invitation; a QR route alone cannot grant enrollment.

## Initiative judgments

| Initiative | Judgment | Delivery recommendation |
|---|---|---|
| 1. Context sources | DOCX/XLSX subset extraction is isolated-spike-tested; HTML import is a source-supported extension; YouTube is permission/rights-conditional | Start with document/table preview + confirmed spans and existing TXT fallback. Keep original/source-version hashes and limitations visible; do not promise all URLs or full workbooks |
| 2. Study decks | Deterministic PNG export is isolated-spike-tested. End-to-end approval and member sharing are unverified | Begin with contributor/admin templates, approved exact deck hash, public-export rights and opt-in member download/share. Browser share fallback required |
| 3. Homepage useful demo | No new public AI runtime verified by this role | Prefer a useful clearly labeled guided example or recorded real flow first; live anonymous AI requires separate abuse/budget/content gate |
| 4. Compact workspace | Primarily UX/component scope | Preserve capabilities, draft conflicts, approval visibility and responsive editing while reducing chrome; use UX study evidence |
| 5. Visual Studio | Architecturally feasible; current payload cannot carry typed blocks | Version contract and build shared member renderer first; deterministic charts/images before paid generation; video separately gated |
| 6. Phone/name + QR + future People | QR with existing OIDC is near-term feasible. Phone-first requires a provider/identity architecture decision; People is a separate integration | Choose explicit enrollment policy; use immutable principals. No account linking by name/phone alone. Verify household, recycling/recovery and contributor identity continuity before rollout |
| 7. Change-request notes | Contributor role's isolated current-API roundtrip verified both notes persisted, author readers omit decision reason, same-revision resubmit fails 409/23505; edited-revision resubmit/approval succeeds | Expose authorized revision-scoped history with actor/time/status and resolution context; avoid creating a second detached comment store; make no-edit retry recoverable |

## Validation completed before these classifications

The [Python spike](../evidence/engineering-spike.py) passed 28 named checks, including paragraphs/table source order, spreadsheet strings/dates/cached and absent formulas, five malicious package boundaries, source/rights/extractor hash changes and ambiguous household contact matching. The [runtime spike](../evidence/engineering-runtime-spike.ts) passed 21 checks against existing URL validation and installed sharp, and created three synthetic PNG deck files. Eight existing source-fetch/security tests passed, including a mocked redirect/oversize transport and DNS pinning. See [exact evidence and limits](../evidence/engineering-validation.md).

These prove narrow extraction/model/transport/rendering behavior with synthetic data. They do not prove Office compatibility, malware resistance, browser social publishing, provider OAuth, SMS delivery/recovery, database migrations/RLS, generated media quality, production performance or customer usability. DOCX/XLSX fixtures are minimal zipped XML packages, not Office-authored compatibility samples. No application/package/configuration/deployment changes or external writes occurred.

## Data and identity decisions to settle

- One immutable principal can have multiple verified identities; a phone is a contact/credential, not the principal. Existing tenant memberships must survive an audited identity mapping. Same-account contributor MFA must continue to work.
- Shared-phone access needs a policy before shipping: one phone credential per principal initially, with alternative credential/support for conflicts. Names cannot resolve ownership. Recycled-number recovery cannot silently inherit existing staff/member access.
- Church member enrollment mode must be explicit: open, approval-required or invitation-only. QR only routes; it never grants contributor/admin capability.
- Source use for AI and source use for public social export are different permissions. A deck review must pin all visible wording, assets, brand/template and study/source versions.
- New block order and asset metadata must be part of approved content hashes. Member preview and delivery should use the same renderer to prevent divergence.
- Current member reader injects fallback prayer, fixed headings/introduction and a John-specific quotation outside saved fields. Shared rendering must include reviewed template/version and Scripture provenance in the approval boundary; reordering JSON is insufficient proof of member/audio parity.

## Dependencies and sequence

Phase A can improve sources, deterministic decks, Studio contract/renderer and QR continuation without a phone-provider migration. Phone-first should have a separate architecture decision record comparing managed OIDC phone identity and a Verify-backed issuer; Entra external-tenant SMS cannot simply become first factor under the checked documentation. A short-term email/OIDC QR flow must be presented as a partial delivery of initiative 6.

Phase B adds provider integrations only after credentialed, rights-approved, budgeted tests: YouTube edit-authorized caption access; a selected phone provider/tenant; People OAuth with actual permissions and ambiguous matching; image/video models in the target region. Cost scenarios in [technical feasibility](../architecture/technical-feasibility.md) are planning arithmetic, not contract quotes.

Cross-review requested from contributor and UX roles: source preview failure labels, deck review granularity, private draft/public export separation, phone conflict/recovery and whether immersive preview accurately reflects member content.
