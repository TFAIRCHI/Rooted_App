# Church member assessment

Research date: 2026-10-31. This is a simulated church-member perspective and task-based expert peer review, not interviews, observed congregation behavior, or actual human usability testing. Fictional data only. Findings distinguish current source, proposed experience, and research prototype evidence. No application or deployment changes are authorized by this assessment.

## Member outcome and priority

“Help me reach my church's teaching, understand it in the time and format available to me, and choose what I share.” A Sunday visitor, returning member, older adult, household sharing a device, screen-reader user, and person with limited mobile data may take different paths. These are design scenarios, not measured audience segments.

Member-value ranking: (6) correct-church access and account continuity; (5) faithful, accessible reading with optional media; (2) deliberate safe sharing; (7) dependable editorial correction; (1) better grounded teaching; (3) truthful public explanation; (4) efficient preparation behind the scenes. This differs from contributor delivery order. Repairing review visibility and establishing a shared renderer are technical prerequisites worth doing before the most visible member features. Phone-first is separately gated by identity-provider/recovery decisions; a QR-to-existing-login improvement alone does not complete it.

## Current-source baseline

| Observation | Member implication | Evidence |
| --- | --- | --- |
| Church/study routes choose authenticated church endpoints when membership exists, otherwise public endpoints | Preserve church reading policy; public reading and authenticated participation are distinct | [member-server.ts](../../../frontend/lib/member-server.ts:13), [core-routes.ts](../../../backend/src/api/core-routes.ts:349) |
| Member sign-in copy requests email and delegates to configured authentication; existing sessions return to a supplied destination | Phone is a future identity change, not a replacement input label | [sign-in.tsx](../../../frontend/components/public/sign-in.tsx:9) |
| Onboarding accepts a named-identity invitation token; membership gates comments/reactions | A copied QR is routing information, not evidence of membership or permission to post | [onboarding.tsx](../../../frontend/components/public/onboarding.tsx:22), [member-conversation.tsx](../../../frontend/components/member-conversation.tsx:15) |
| Reader splits a plain text body, maps fixed sections, and supplies fixed introductory text, a fixed reflection heading, and a fallback prayer; quoted passage text is hard-coded for John 6:68–69 only | New visual rendering must preserve approved teaching instead of inserting unapproved template prose or suggesting a reference is the complete passage | [member-study-reader.tsx](../../../frontend/components/member-study-reader.tsx:44) |
| Browser read-aloud starts only on request, supports pause/resume/stop, and leaves text available if unsupported | Preserve this optional behavior when adding media; future block narration needs a deliberate reading sequence | [study-audio.tsx](../../../frontend/components/study-audio.tsx:12) |
| Completion is browser-local, scoped by church, user and study; blocked storage does not prevent reading | Avoid implying completion syncs across devices or records spiritual progress | [member-study-reader.tsx](../../../frontend/components/member-study-reader.tsx:9) |
| Discussion comments have author names, private pending/declined states, questions and private reports | A social card must be exported from a dedicated approved public artifact, never a screenshot of this page | [member-conversation.tsx](../../../frontend/components/member-conversation.tsx:34) |

These are source observations, not runtime reproduction or a claim about all deployed environments. Engineering's [assessment](data-engineer-assessment.md) independently identifies text-only content contracts, outbound SMS rather than phone authentication, and Publishing rather than People integration.

## Seven feature decisions and acceptance criteria

### 1. Richer sources improve the study indirectly

Members need accurate quotations, understandable context and meaningful applications; they should not need to learn DOCX or spreadsheet extraction. Support all four requested source types in contributor research, with reviewed excerpts and provenance. Keep internal sermon notes, workbook identities and pastoral material out of public excerpts. A source being available for teaching assistance does not make it appropriate for a public card.

Acceptance: each published Scripture quotation identifies its reference/translation; charts retain units and an intelligible source label; excerpt context does not reverse the original meaning. An author/reviewer can trace claims to the exact reviewed document paragraph, caption timestamp, captured web text, or spreadsheet range without requiring members to open private source files. Import failure or omitted content cannot silently become invented teaching. The author's source-review checks, not member exposure to raw imports, carry this responsibility.

### 2. Contributors/admin prepare decks; members choose to share

“Share this study” should open approved Scripture, quote, chart and multi-card choices. State that these are public excerpts even when the complete study is members-only. Show church and Rooted branding without obscuring the passage. Preview exactly what leaves the app and a text alternative/caption; allow individual cards or an explicitly ordered selection. Download is a valid fallback when native sharing or several images are unsupported. Opening, cancelling or reading a study must never post.

Acceptance: only the exact published/approved deck rendition appears; a study change triggers defined stale/withdrawn behavior. Card export contains no member name, reaction, private comment, prayer request, draft, account details or church-directory data. A clear disclosure says downloaded/shared copies can travel outside the church and cannot be recalled. Cancel restores the same reading position/focus. A native share completion is reported as “Shared with your device” or similar, never proof a social post appeared. Multi-card order is visible, individually selectable, and preserved in downloaded numbering; target-app order/support remains subject to device acceptance. Chart cards have accompanying readable data/description. No member must connect a social account or share to finish reading.

### 3. Useful and truthful homepage CoWriter demonstration

Members may use this to understand what the church is adopting. Show a fictional source, a human correction and the saved draft/reviewer handoff; make clear which parts are actual product recordings, guided samples or future concepts. A polished recording is useful if it explains how church staff retain responsibility. Do not imply every church's teaching is automatically AI-generated.

Acceptance: explicit sample status, captions, transcript, controls and keyboard access; no autoplay audio; a useful text explanation without playing video; no login or paid generation just to view the example. Proposed future Studio/phone features carry visible concept labels. A later real participant can explain who provides sources, who checks the result and whether the demo is live; research role simulation does not establish this comprehension.

### 4. Compact staff workspace

This primarily helps members through reliable publication and fewer missed corrections. Do not apply a staff “no scroll” target to a contemplative member reader. Keep reading at comfortable text sizes, with clear church/study context and simple return navigation. Preserve the member preview as a view of actual revision content; errors and unresolved requests must remain visible to staff.

Acceptance: staff can identify saved revision, review state and unresolved changes from each main task. Published member rendering matches the reviewed revision. At 320px and 390px widths and 200% zoom, text reflows without horizontal page scrolling; primary reading and sharing controls remain reachable by keyboard. These are proposed checks, not proven prototype coverage.

### 5. Separate Studio and immersive reader

Studio is a creator tool; the member receives an authored sequence. An image, diagram or video should clarify the teaching without becoming a compulsory obstacle. Reordered blocks must change visual, keyboard, screen-reader and narration order together. Offer text alternatives for images, a data table/description for charts, captions/transcript for video, visible duration/data cues and optional playback. A full-screen view needs a named Exit control and predictable focus return.

Acceptance: save/reload/approve/publish a synthetic study with text → chart → Scripture → image → video → application and confirm the same order/content/asset version in editor preview and member reader. Read it with images unavailable, video blocked, browser read-aloud unsupported, reduced motion enabled, and keyboard only; the teaching and completion action remain usable. Video never autoplays, opens unexpected external windows, or gates completion. Decorative images have empty alternatives; informative diagrams have meaningful equivalents, not filenames. Narration and on-screen text do not invent fallback teaching. Reading-time labels distinguish text time and optional video duration. Published accessibility is checked in the shared renderer, not inferred from an image mockup.

### 6. Phone/name, church QR, enrollment, later People association

Prefer phone as a convenient way to return, with an explicit country and familiar name prompt, while preserving a workable alternative. Display the church name before sign-in and after it. Explain the actual enrollment policy: “Join [church]'s member space” is not formal ecclesial membership, a directory invitation, permission to receive reminders or a staff role. For an open church, one clearly labeled continue/join action can enroll after verification; approval-required/invitation-only churches need honest pending/invitation states. QR routing and authentication should return to the intended study.

| Scenario | Required behavior / concrete acceptance |
| --- | --- |
| Existing account | Sign in using the existing credential or explicitly link after verification; retain church memberships, permitted role and prior history. No duplicate account or silent merge based on phone/name |
| Shared household phone | Explain that the number cannot distinguish independent people; provide another credential or church-assisted recovery. Do not show a household account list or let a name field choose someone else's identity |
| No SMS, landline, delayed/expired code, unsupported country | Provide an actual alternative sign-in/recovery path; keep church and return destination through retry. Show resend timing and actionable errors; do not repeatedly charge/send without deliberate action |
| Changed/recycled phone or lost device | OTP possession alone must not inherit an established account or staff role. Offer reviewed recovery, revoke old sessions where required, and preserve the old account rather than silently replacing it |
| Already signed in as another person | Show the current account/name before enrollment and allow switching; shared-browser persistence must be clearly communicated |
| Multiple churches | Join/read the QR's church explicitly; do not silently switch another membership or apply another church's consent. Keep church identity in navigation and make returning to existing churches discoverable |
| Stale, copied, incorrect or revoked QR | Re-resolve church and policy server-side; show actionable unavailable/wrong-church states. Never grant contributor/admin privileges from the QR |
| Reminder choice | Login verification, church enrollment, optional SMS reminders and future directory association are separate choices/purposes. Reading remains available without reminder consent under church policy |
| Preferred name | Explain whether the name will appear with church comments; allow edits without changing account ownership. Do not require a legal name to read |
| Future Planning Center | Never block reading if disconnected/unmatched. A household/shared number or name produces a review case, never automatic person merge. Cross-church associations remain separate and revocable |

Acceptance: use synthetic fixtures for each row; verify no identity/church context leakage, no staff-role escalation, idempotent enrollment and destination restoration. Engineering must prove the chosen phone provider and same-account contributor verification; the mockup cannot do so. Avoid promising SMS-less phone authentication unless that alternative has a tested provider path.

### 7. Visible editorial requests

Members mostly benefit from correctly revised teaching. Keep internal approval requests private to authorized staff; do not copy them into member discussion. If an already published study materially changes, define a dated “Updated” indication and reader behavior instead of leaving contradictory stale excerpts. Do not retroactively label a prior member completion as consent to new content.

Acceptance: a contributor can find the reviewer, timestamp, exact revision, requested action and response; approving a replacement does not silently approve changed cards/media. Members see only the currently available published revision; withdrawal has a clear unavailable state. A stale public deck is either removed or explicitly handled by the approved policy. New publication must not expose reviewer notes or private working material.

## Peer review evidence

Early source-based feedback was sent to UX and engineering: explicit public-excerpt disclosure; cancel/focus/reading-position preservation; no private discussion screenshots; no forced media; authored reading order; shared-phone/no-SMS/existing-account/multi-church QR cases. A source-fidelity issue was escalated to the root and UX: fixed current-reader teaching must not migrate into unreviewed authored blocks.

### Completed rendered and local-control review

The member role independently exercised the static localhost storyboard at `http://127.0.0.1:3091` using installed Playwright Core and headless Microsoft Edge. Reproduction: `node "research/Product Experience Initiative 20261031/evidence/member-peer-review.mjs"` from the workspace root. The final run exited 0. [Script](../evidence/member-peer-review.mjs), [observations](../evidence/member-peer-review-results.json). These are task observations with synthetic state, not application integration or human participant results. An initial run used the old “Keep reading” selector while UX renamed that action; the final script uses the current cancellation label and completed successfully.

| Task / exact issue | Initial feedback | Final observed result |
| --- | --- | --- |
| Select Salem/North instead of Portland, then continue | Selection only changed `aria-pressed`; next screen hard-coded Portland. This could misrepresent church enrollment | UX added church state/URL persistence. Independent choose → verify → name → enroll → Read study preserved “Grace Church · Salem” |
| Finish member enrollment and read without sharing | Completion screen offered only a share preview | UX added primary “Read the study” and secondary optional sharing; both appeared after enrollment |
| Understand exported privacy/public audience | No clear warning that downloads can leave the church permanently | Rendered share page explicitly says anyone may forward cards and copies cannot be recalled; card preview includes church + Rooted branding and no account/discussion data |
| Cancel sharing and resume study | “Keep reading” returned to phone completion, not study text | Cancel returned to `?view=reader&church=north#member-reflection`; active element was `member-reflection`, scrolled into view |
| Decline reminders and sharing | Required explicit optional choices | Reminder box was unchecked; sharing button disabled before choice. Keyboard Space on consent and Enter on share revealed local sample options; no native service or post invoked |
| Read responsive layout | Check actual overflow rather than infer from scaled images | Phone, share, immersive preview and reader each had document width equal to viewport width at 320, 390 and 1280px (12 observations) |
| Understand informative diagram without pixels | Diagram labels are small on phone | SVG title explains remain → receive → bear fruit and identifies it as illustration rather than measured data; full assistive-technology verification remains open |

Actual PNGs were inspected with `view_image`: [identity conflict](../mockups/captures/26-phone-identity-conflict.png), [member share](../mockups/captures/29-member-share.png), [independent phone capture](../evidence/member-review-phone-390.png), [independent sharing options](../evidence/member-review-share-390.png), and [independent Salem reader](../evidence/member-review-reader-390.png). The recovery screen explains that a familiar number does not authorize opening/merging another account. The reader gives teaching room to breathe, preserves a visible diagram-before-reflection sequence, and exposes optional sharing after teaching. The focused reflection outline in the independent reader capture is expected keyboard focus after cancellation. Earlier full-page captures taken while scrolled showed an offscreen fixed skip-link capture artifact; final captures scroll to the top after separately recording return focus/position.

Remaining proposal gaps are explicit: the storyboard previews one card at a time and describes an all-four export; it does not demonstrate individual/multiple selection, a Scripture/quote/chart type chooser, actual files leaving the browser, or destination ordering. Native sharing/device behavior remains untested. The alternative login is descriptive only, readonly sample phone/name fields do not prove authentication, and account recovery is a concept state. Media-disabled reading, hosted-video captions, 200% zoom, assistive-technology operation, production approval/hash enforcement, persistence, and mobile device QR scanning are not established by these checks. The static reader demonstrates one fictional sequence, not editor-to-published renderer parity. No overall accessibility, product usability, actual-human validation, live SMS, social posting or People integration pass is claimed.

Next human validation should recruit a few real church readers across returning/visitor, shared-device and accessibility needs, using fictional studies. Ask them to choose the correct church, recover from an unavailable code, explain what enrollment/reminders mean, read without video, preview a public excerpt, and cancel back to their place. Observe completion and comprehension rather than asking only whether the screens look good.
