# Primary source register

Checked during this initiative, October 31, 2026, America/New_York. Provider documentation supports the stated capability/constraint; it is not proof that Rooted has integrated that provider. A document’s update date, where available, is separate from our access date. Engineering’s [evidence ledger](evidence/engineering-validation.md) records additional exact source versions, commands and limits.

| Source | Supports | Important scope |
|---|---|---|
| [Google: captions download](https://developers.google.com/youtube/v3/docs/captions/download) | Authorized caption-track download and required video edit permission | Does not grant access to arbitrary public-video transcripts |
| [Google: captions list](https://developers.google.com/youtube/v3/docs/captions/list) | Caption-track metadata, not the transcript itself | Separate authorized download needed |
| [YouTube developer policies](https://developers.google.com/youtube/terms/developer-policies) | Handling/reuse restrictions, including audiovisual downloading/caching | No unauthorized media-scraping shortcut proposed |
| [Microsoft: Word table structure](https://learn.microsoft.com/en-us/office/open-xml/word/how-to-insert-a-table-into-a-word-processing-document) | Paragraph/table/row/cell representation used in the research fixtures | Does not certify a maintained production parser |
| [Microsoft: spreadsheet formulas](https://learn.microsoft.com/en-us/office/open-xml/spreadsheet/working-with-formulas) | Formula expression and cached stored value are distinct | No calculation or freshness guarantee |
| [Microsoft: Excel date systems](https://support.microsoft.com/en-us/excel/date-systems-in-excel) | 1900/1904 workbook date interpretation | Real workbook styles/formats still need integration tests |
| [OWASP: file upload](https://cheatsheetseries.owasp.org/cheatsheets/File_Upload_Cheat_Sheet.html) | Layered validation, bounded storage/extraction and isolation | Existing synthetic rejection tests do not replace scanning/fuzzing |
| [OWASP: SSRF prevention](https://cheatsheetseries.owasp.org/cheatsheets/Server_Side_Request_Forgery_Prevention_Cheat_Sheet.html) | Network/input/redirect boundary considerations | Rooted already has defended fetching; extend it rather than assuming it is absent |
| [W3C: Web Share](https://www.w3.org/TR/web-share/) | User-initiated device sharing and capability-dependent file support | No guarantee of installed apps, multi-card order or completed social posting |
| [WAI: accessible media](https://www.w3.org/WAI/media/av/) | Captions/transcript/player/visual-information alternatives | A mock play control is not a recorded accessible video |
| [WAI: modal dialog pattern](https://www.w3.org/WAI/ARIA/apg/patterns/dialog-modal/) | Modal focus, keyboard and return behavior | Not a reason to put all long authoring tasks in dialogs |
| [Chrome: Document Picture-in-Picture](https://developer.chrome.com/docs/web-platform/document-picture-in-picture/) | Specific optional browser window capability | Not the cross-browser baseline for the compact workspace |
| [Microsoft: External ID customer FAQ](https://learn.microsoft.com/en-us/entra/external-id/customers/faq-customers) | External customer SMS is not a primary authentication factor | Workforce/B2C/other identity products are not interchangeable with the current tenant |
| [Microsoft: customer MFA](https://learn.microsoft.com/en-us/entra/external-id/customers/how-to-multifactor-authentication-customers) | Customer MFA/SMS context | Does not make a phone/name form a member identity issuer |
| [Twilio Verify API](https://www.twilio.com/docs/verify/api), [verification resource](https://www.twilio.com/docs/verify/api/verification) | Verification/challenge lifecycle and contact representation | Rooted’s existing outbound Messages adapter is not this integration |
| [Twilio Verify practices](https://www.twilio.com/docs/verify/developer-best-practices) | Retry, channel and verification design considerations | Identity linking, membership and recovery still belong to the application architecture |
| [Twilio Verify pricing](https://www.twilio.com/en-us/verify/pricing) | Dated illustrative US verification/message cost inputs | Dynamic/account/region fees; scenarios are not quotes or a spend guarantee |
| [Planning Center authentication](https://api.planningcenteronline.com/docs/overview/authentication) | Product-specific OAuth scopes, including Publishing and People | Existing Publishing access does not imply People permission |
| [Planning Center People reference](https://api.planningcenteronline.com/docs/apps/people/versions/2026-10-05), [PhoneNumber](https://api.planningcenteronline.com/docs/apps/people/versions/2026-10-05/vertices/phone_number), [Person](https://api.planningcenteronline.com/docs/apps/people/versions/2026-10-05/vertices/person) | Organization/person/phone association model; referenced API version | No real directory was connected, queried or imported |
| [Planning Center rate limits](https://api.planningcenteronline.com/docs/overview/rate-limiting) | Response-driven backoff/rate handling | Future sync must obey actual response limits rather than a fixed assumption |
| [Crossway permissions](https://www.crossway.org/permissions/), [Biblica permissions](https://www.biblica.com/permissions/) | Translation/format/use-specific Scripture quotation conditions | No blanket public deck/artwork license is inferred or granted here |

## Local authority

The current application source, its contracts/migrations and the exact local test results are the authority for current behavior. Older research includes future proposals; it is not evidence that the features are live. The contributor/member/engineering assessments cite specific local files/lines. Runtime approval evidence is in [approval-roundtrip.json](evidence/approval-roundtrip.json), with an isolated fictional database and no production queries.

No external source is described as having reviewed, endorsed or partnered with Rooted. No third-party content was copied into a production source library, deck, directory, or recording.
