# Decisions and recommended implementation sequence

This is a proposed product/engineering path, not an authorized build or a calendar commitment. Ordering reflects today’s demonstrated workflow gaps, prerequisites and member value. Effort bands are relative; estimates require implementation scoping.

## Reconciled role decisions

| Decision | Contributor/admin concern | Member concern | Engineering/UX resolution |
|---|---|---|---|
| Repair visible review history first | Cannot act on hidden feedback or know what changed | The published study should reflect proper review | Expose existing stored events under draft-read authorization; pin unresolved requests across edits; handle repeated review cycles |
| Task-based workspace | Need less scrolling and fewer lost-context steps | Do not compress the reading experience to match a staff target | Compact desktop controls/status; natural mobile/reading flow; one authoritative draft state |
| Reviewed source tray | Practical document/link/table input | Accurate source-aligned teaching, not invented context | Bounded extraction → visible selection → rights/review → immutable spans → grounded proposal |
| Separate verbal and visual creation | Need visual control without reopening every writing conversation | Same approved text/order/media in the reader | Distinct CoWriter/Studio tasks, shared versioned content contract and renderer |
| Deck is a public rendition | Church controls brand, excerpt and release | Member chooses sharing and sees what leaves the app | Separate exact-rendition approval/public-audience enablement; download fallback; no private reader screenshot |
| Phone as preferred entry, not durable identity | Simple church routing and future directory association | No wrong account, household leak or loss of existing membership | Stable principal + verified credentials; provider choice and recovery; QR routing can precede phone integration |
| Genuine recorded demonstration | Need visitors to see practical saved work | Need honest explanation of AI and human responsibility | Record current real workflow with fictional material; clearly label recording/replay, no public model endpoint initially |

The member role ranked easy/correct access and faithful reading highest; the contributor ranked visible feedback and reliable authoring highest. These are not conflicting product goals. The sequence fixes the review/rendering foundations while allowing the QR and demo improvements to proceed without waiting for full Studio.

## Proposed phases

### Phase A — Make the existing workflow legible

**Scope:** item 7’s protected history/latest-request display, recoverable resubmission, compact task shell/status/primary actions, and a genuine recorded demo of today’s CoWriter. **Relative effort:** small-to-medium for the targeted repair; medium for the shell depending on draft-state/navigation refactor.

Exit: contributor and approver exchange non-empty notes in separate fresh sessions; notes remain after edit/reload; wrong tenant/member access is denied; same-revision retry has a defined recovery; exact-revision approval is preserved. Primary desktop actions remain visible and keyboard/mobile reading remains usable. The recorded demo shows a real saved result with reviewed fictional material and accessible playback.

Do not expand the first repair into a new general-purpose chat service. Reuse assignment notes, decisions and revision comments as typed events; richer resolution/unread/anchors can follow without hiding the immediate reason.

### Phase B — Improve access and source preparation

Two parallel tracks:

- **Sources:** DOCX/text and pasted cells first; then selected XLSX ranges and approved-host web extraction; authorized YouTube captions when permissions/channel tests are complete. Reuse existing defended fetching and source snapshots.
- **Member entry:** church QR and return routing through current verified authentication, plus explicit open/approval/invitation enrollment policy. Preserve the preferred phone-first design, but do not silently substitute QR/email for delivery of that later requirement.

**Relative effort:** medium; source parser/scan/storage and enrollment endpoints are real backend work. Exit: hostile-file/network cases, exact source coverage/provenance, private scope, retry/idempotency, church return context and three enrollment policies pass real integration tests.

### Phase C — Establish Studio’s content and renderer foundation

**Scope:** versioned ordered blocks, stable IDs, deterministic diagram/chart rendering, durable approved asset references, legacy adaptation and one preview/member renderer. Make existing template/fallback prose explicit or remove unsupported defaults from the new contract. **Relative effort:** large because payload, renderer, accessibility, approval hash and publication meet here.

Exit: save/reload/approve/publish a mixed block study and compare exact bytes/order/assets in preview and reading, including narration and text alternatives. Unknown blocks, stale jobs/assets and private media fail safely. Existing approved legacy studies keep defined behavior.

AI visual generation and video generation are not required to prove this foundation. Start with authored/approved assets and deterministic output; add provider-backed candidates only after model availability, rights, cost and moderation tests.

### Phase D — Release approved public decks

**Scope:** controlled branded templates, exact deck revision/rendition approval, public-audience policy, downloaded images/captions/link, member preview/choice/cancel. **Relative effort:** medium-to-large depending on shared asset/version foundation.

Text-only quote/Scripture decks can be scoped before full Studio if they use the same approval/rendition discipline. Rich media/chart decks depend on Phase C’s asset and data foundations. Exit: actual persisted export and authorization tests, long-text/crop/contrast checks, no private data, stale/withdraw behavior, device-native sharing/fallback tests and explicit public destination.

Do not make a device share promise contingent on native support: downloadable PNGs/captions are the reliable baseline. Do not count “share sheet opened” as “social post published.”

### Phase E — Deliver the preferred phone-first identity path

**Scope:** choose a managed phone-capable identity provider or narrowly scoped issuer, verified phone credential mapping, stable principals, existing-account linking, household ambiguity/recovery, OTP abuse/spend limits and staff assurance separation. **Relative effort:** large and security-sensitive; it is not just a UI form change.

Exit: live owned-number provider tests, replay/expiry/rate/abuse/recovery cases, existing-session/account migration, multiple churches, name privacy, country/unsupported-number handling and operational ownership all pass. Member access is not staff authority or marketing consent.

**Planning Center People follows separately:** explicit church OAuth People scope, permitted reads, person/phone candidate reconciliation, source-of-truth decisions, rate-limit/revocation/deletion behavior. Publishing integration does not satisfy this dependency.

## Architecture decisions to retain

1. A source capture and its reviewed version are different records. Large upload acceptance does not imply full model ingestion.
2. Study text, block order, informative alternatives and media/rendition hashes participate in review/publication integrity.
3. Public deck approval is distinct from study approval, and member sharing is an explicit action distinct from either approval.
4. Contributor/admin deck operations need dedicated capabilities. Existing administrator review authority does not imply `content:edit` or unrestricted media/authoring rights.
5. Read-only review history uses the existing aggregate/tenant authorization boundary and typed events. A reply does not resolve an approver’s request or approve new content.
6. Phone/name/directory matching do not grant identity or membership; stable issuer/subject/principal links and enrollment policy do.
7. Staff authentication/MFA is preserved when member identity options expand.
8. Media/extraction/export work is asynchronous, idempotent and bounded. Reuse proven job patterns, not an assumed live image/video capability in the current text model/worker.
9. The homepage demonstration is recorded/current or clearly a future concept; no secret-backed public AI endpoint is implied.

## Decisions needed before a build brief

| Decision | Recommended initial default | Owner |
|---|---|---|
| Which phase first? | A, with source/QR discovery in parallel | Product/church leadership |
| Church member-space enrollment | Explicit per-church open/approval/invitation policy; no staff grants | Church administrator + product |
| Public decks from private studies | Only a separately approved public excerpt; full study retains its reading policy | Church approver/policy owner |
| Deck authorship/review | Dedicated permissions for contributors and selected administrators; exact artifact review | Product + engineering + church |
| Phone provider and recovery | Evaluate managed OIDC-capable member identity first; retain current staff assurance | Engineering/security + product |
| Scripture/media rights | Approved translation/use and church-owned/licensed assets | Church/content owner |
| First Studio formats | Structured text, deterministic diagrams/charts and approved images; optional authorized video later | Product + UX + engineering |
| Cost envelope | Per-church/user generation and verification budgets with clear operational ownership | Product/operations |

These are future decisions; research did not enable integrations, change enrollment policy, subscribe providers or send messages.

## Pilot success measures

For each authorized phase, establish a real baseline before setting improvement targets: successful source review without omitted-context surprise; contributor can find/act on approver feedback; correct church/account arrival; exact preview/published parity; accessible reading; voluntary sharing with no private-data exposure; and controlled provider spend. Run a small real contributor/approver/member pilot and inspect failures. Agent simulations and test counts cannot establish adoption, comprehension, spiritual impact or percentage time savings.
