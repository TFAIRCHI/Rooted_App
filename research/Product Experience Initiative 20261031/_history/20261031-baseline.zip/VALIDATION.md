# Validation, peer corrections and remaining proof

Research validation completed October 31, 2026 local time. UTC timestamps after midnight can read November 1. **No application implementation, deployment or provider account connection was performed.** This report labels each kind of evidence separately; it does not combine test counts into a claim that all seven products are implemented.

## What actually ran

| Evidence | Actual result | What it does not prove |
|---|---|---|
| [Synthetic extraction/model spike](evidence/engineering-spike-results.json), [script](evidence/engineering-spike.py) | **28 checks passed**: DOCX text/table order; XLSX strings/booleans/date systems/formula cached/missing values; hostile package/XML/path/size rejects; source/revision/rendition hashes; household-phone ambiguity | Maintained production parser, complete Office semantics, malware scanning or real identity match |
| [Current-module/runtime export spike](evidence/engineering-runtime-results.json), [script](evidence/engineering-runtime-spike.ts) | **21 checks passed**: URL/host/public-address boundaries and three actual portrait PNG exports using installed tooling | Real website/channel integration, live social sharing, production rendition delivery |
| Existing source-fetch/security tests | **8 passed**, including mocked redirect/DNS-pinning behavior; recorded in [engineering ledger](evidence/engineering-validation.md) | Live hostile-network or provider-account acceptance |
| Existing frontend component tests | **13 passed across 3 files**; [contributor assessment](roles/contributor-assessment.md) names the exact command | New note reader, Studio/media persistence or approval UI roundtrip; fetch is mocked |
| [Current-API approval roundtrip](evidence/approval-roundtrip.json), [research harness](evidence/approval-roundtrip.ts) | Actual local OIDC/CSRF/capability/ETag/hash/DB workflow with fictional contributor/admin/member identities; note/reason storage, read gap, same-revision conflict and new-revision recovery reproduced | Production data inspection or a repaired application UI; no new history endpoint was implemented |
| [UX task checks](mockups/browser-validation.json) | **37 checks passed**, **35 reflow layouts** without horizontal overflow; zero script errors/external requests | Ingestion, auth, durable save, media, provider or publishing integration |
| [Keyboard-focus checks](mockups/keyboard-focus-validation.json) | **57 focused controls** unobscured in compact source/Studio/review concepts at 1366×768 | All browsers/assistive technologies or the eventual application implementation |
| [Independent member peer tasks](evidence/member-peer-review-results.json) | **22 recorded checks**: selected church/context, opt-in defaults, reading/share/cancel/focus and width cases | Real member usability, SMS delivery, arbitrary multi-card selection or native target-app behavior |
| [Independent engineering peer checks](evidence/engineering-peer-browser.json) | **15 checks passed**: exact approved deck binding, stale state, phone/church boundary, actual shared six-block order in research previews | Production versioned renderer/asset save/publication parity |
| [Rendered image manifest](mockups/captures-manifest.json) | **38 PNG screen captures**, four 1080×1080 deck exports/caption, plus three portrait export-spike PNGs | A working upload, scannable/authenticated QR, recorded genuine AI demonstration, or live social integration |

The [source-preservation report](evidence/application-source-preservation.json) confirms **zero changes across 215 application/source files and all 121 prior release inputs** after role work. The [artifact check](evidence/artifact-validation.json) verified all 259 relative document links and decoded the screen/export images, including exact 1080×1080 card dimensions. The research server is isolated at `127.0.0.1:3091`; no production app server, new app build or Next development process was needed for the mockups.

## Approval runtime findings

The isolated harness established real local contributor/admin/member sessions, saved a plan, approved it, created and submitted content with a non-empty contributor note, then requested changes with a non-empty reason.

- Both strings persisted in their respective database rows.
- Author aggregate read returned 200 without the reviewer reason; review-request read returned 200 with the assignment note but no reason; revision-comment read returned an empty list. This reproduces the data-reading gap without claiming a production incident was inspected.
- Empty reason returned 422; wrong reviewed hash 409; stale version 412. Member aggregate/request/comment reads were denied with 403; a cross-church read returned 404.
- Resubmission of unchanged revision returned 409 with PostgreSQL uniqueness code 23505; original state/note survived rollback. Saving a new revision then resubmitting returned 200; independent approval returned 201 and retained the prior reason.
- External-service/provider request count was zero. The owned API/identity server/pools closed, the exact owned disposable database was dropped and absence was verified.

See [item 7](items/07-approval-conversation.md) for exact route/storage/UI trace and the repair acceptance matrix.

## Peer review changed the proposal

| Finding | Correction / final disposition |
|---|---|
| Phone church chooser reset to the example’s original church | Selected church preserved through verification, enrollment, reading, sharing and reload; independent member tests pass |
| Successful enrollment offered sharing without a primary reading path | Read study is the main continuation; sharing stays optional |
| Cancelling sharing lost the reading context | Returns to the reflection with focus; tested |
| Public exports lacked a clear copy/recall explanation | Visible public-excerpt/copy disclosure and safe caption/destination; reading/private activity excluded |
| Deck “approval” used the current changes-requested draft | Prior approved study r10 and exact deck rendition/caption/destination are distinct from draft r12; stale state blocks approval; final hypothetical-r13 caption corrected |
| Source count implied unreviewed content was reviewed | Separate included and awaiting-review states/count, source excerpt locator and gated confirmation |
| Main desktop actions fell below the fold | Compact chrome and an accessible desktop rail; first-viewport action tests and 1366×768 captures |
| Reordered block list did not change preview/member rendering | Shared fictional block renderer/order implemented in the research artifact; independent DOM-order checks pass |
| Fixed action rail could cover focused Studio controls | Document scroll padding/control margins; all 57 focused controls are unobscured; no extra nested scroller introduced |

Contributor and engineering peer reports explicitly reviewed corrected images/live research controls. Earlier issues are kept in those reports as history; they are not silently counted as passes before correction.

## Provider and human proof still needed

1. **Sources:** production parser/library/hostile-file corpus, scanning/storage/worker limits, real approved webpage extraction, authorized caption account/permissions/expiry/quota and complete source-to-request isolation.
2. **Decks:** real persisted versioned exports/access controls, chosen translation/media rights, per-card/arbitrary subset behavior, withdrawal, actual iOS/Android target apps and accessible fallback outcomes.
3. **Demo:** genuine current-application recording or clearly labeled replay, final captions/transcript/player, hosting/performance, and real viewers understanding what is saved and who approves.
4. **Workspace:** actual routing/draft/concurrency/error recovery and real contributor task comparison. The screenshots do not measure time savings.
5. **Studio:** versioned application schema, durable asset jobs, shared published renderer/legacy compatibility, mixed-content approve/publish tests, accessibility/narration, and separate image/video provider quality/cost tests.
6. **Member access:** chosen phone-capable identity architecture, owned-number delivery/recovery/abuse tests, safe existing-account linking, three enrollment policies, and separately authorized Planning Center People sync.
7. **Review repair:** implement the protected history/UI and defined repeated-review semantics, then run fresh separate browser-session roundtrips. Current storage/API proof is not proof that the UI has already been fixed.

Real device testing, 200% browser toolbar zoom, screen-reader testing, actual church users, a full malware corpus and live provider acceptance were not performed. The keyboard/reflow results are useful bounded evidence, not a universal accessibility/usability certification.

## Reproducing research safely

The [engineering ledger](evidence/engineering-validation.md), [mockup guide](mockups/README.md), and scripts document exact commands/fixtures. Re-run only the needed research checks. The approval harness creates its own guarded loopback database and closes/drops only its owned resources; it is not a production diagnostic or permission to reset the local development database. No package installation is required. Do not point any fixture or simulated enrollment action at production.
