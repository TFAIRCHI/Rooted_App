# Product Experience Initiative

October 31, 2026 · **Research only. No application or production changes.**

Four requested agent perspectives—church contributor, UX, data engineer and church member—reviewed all seven ideas, exchanged findings, exercised isolated tests and corrected the rendered concepts. These are role-based expert/heuristic reviews, not recruited-human church research or proof that the proposed integrations already work.

**[Open the interactive research storyboard](http://127.0.0.1:3091)** · [Actual mockup image guide](mockups/README.md) · [Priorities and rollout proposal](DECISIONS_AND_ROADMAP.md) · [Evidence and limits](VALIDATION.md)

## Recommended path

Start with the **approval-conversation repair and compact task workspace**. They remove a demonstrated obstacle from today’s workflow. Show today’s real CoWriter value with an honest recorded walkthrough. Add reviewed source imports next. Build the shared visual content/renderer foundation before promising an immersive Studio. Treat public decks as separately approved assets, and phone-first sign-in as a deliberate identity integration rather than a new input field.

Your preferred phone-first experience remains the target: phone → verified code → name when needed → correct church/member space. QR routing can improve sooner using the current verified login. The existing Entra customer configuration does not provide SMS first-factor sign-in, and Planning Center People is not the existing Publishing integration.

| Item | Best path forward | What the evidence establishes |
|---|---|---|
| [1. Context inputs](items/01-cowriter-context-inputs.md) | Reviewed DOCX/text/cells first; approved-host web/XLSX ranges; authorized YouTube captions with transcript fallback | Extraction/security/provenance spikes passed; production parsers and real channel/host integration remain untested |
| [2. Social sharing](items/02-social-sharing.md) | Exact-version approved public excerpt decks, church + Rooted branding, member opt-in download/share | Actual PNG export and visual sharing flows tested; native/social-app delivery and production deck service are unverified |
| [3. Genuine CoWriter demo](items/03-real-cowriter-demonstration.md) | Captioned recording of the real current workflow plus inspectable recorded steps | Concrete recording brief/player concept; no new genuine recording or live visitor AI service was produced |
| [4. Compact contributor/admin UX](items/04-compact-contributor-workspace.md) | Task navigation, context/status, selected pane, desktop action rail and full preview | Research interactions, first-view actions, reflow and keyboard visibility tested; actual draft/route integration and human efficiency remain future gates |
| [5. Studio Creator](items/05-studio-creator.md) | Separate visual composition task, stable ordered blocks, shared approved renderer, then AI visual candidates/video | Research block order is shared and tested across previews; durable application media/render/publication is not implemented |
| [6. Member access](items/06-member-access.md) | QR + existing auth first; evaluate managed phone-capable identity/verified links; People sync later | Phone/church/error flows and synthetic identity ambiguity tested; no SMS/provider/People integration was exercised |
| [7. Approval comments](items/07-approval-conversation.md) | Protected revision-anchored review history and visible latest request/reply; recover no-edit resubmit | Real current-API roundtrip confirms storage/read gap and reproduces the same-revision conflict, with tenant/member guards and cleanup |

## The most concrete finding

Both the contributor’s submission note and the approver’s request-changes reason persist in the current backend. The author’s ordinary reads do not expose the reviewer’s reason. This is a demonstrated retrieval/display gap, not evidence that all notes are lost. A same-revision resubmission also returns a conflict; saving a new revision and resubmitting succeeds. See the [runtime-backed repair brief](items/07-approval-conversation.md) and [actual results](evidence/approval-roundtrip.json).

## True mockup images

The package contains **38 actual rendered PNG screen captures**, including desktop, phone, empty/error/stale states and compact 1366×768 first views. It also contains **four actual 1080×1080 branded deck PNGs** and three portrait export-spike images. These are inspectable files, not descriptions of future images. The player and phone controls remain explicitly labeled concepts; no credentials or uploads are collected.

| Start here | Image |
|---|---|
| Compact source review and visible action | [Open screenshot](mockups/captures/35-compact-source-first-view.png) |
| Separate Studio canvas and block controls | [Open screenshot](mockups/captures/36-compact-studio-first-view.png) |
| Visible approval conversation | [Open screenshot](mockups/captures/17-review-conversation.png) |
| Member public-deck preview/choice | [Open screenshot](mockups/captures/29-member-share.png) |
| Phone-first concept with church context | [Open screenshot](mockups/captures/19-phone-welcome.png) |
| Practical homepage demonstration concept | [Open screenshot](mockups/captures/12-homepage-demo.png) |

The [image guide](mockups/README.md) links every source type, Studio/chart/video state, review screen, phone exception and member rendition. The [capture manifest](mockups/captures-manifest.json) records actual routes/viewports. The optional server serves only these research artifacts:

```powershell
node "research/Product Experience Initiative 20261031/mockups/serve.mjs"
```

## Architecture and decisions

- [Architecture overview and proposed boundaries](architecture/README.md), with [diagram](architecture/product-architecture.png).
- [Engineering feasibility, records, provider dependencies and cost scenarios](architecture/technical-feasibility.md).
- [Decision log, staged roadmap, ownership and pilot gates](DECISIONS_AND_ROADMAP.md).
- [Primary sources](SOURCES.md), checked during this initiative.
- [Research charter and evidence classifications](RESEARCH_CHARTER.md).

## Four perspectives and peer review

| Role | Initial assessment | Cross-review |
|---|---|---|
| Church contributor | [Assessment](roles/contributor-assessment.md) | [Final image review](roles/contributor-peer-review.md), current-API approval test |
| UX specialist | [UX assessment](roles/ux-assessment.md) | Rendered concepts, interaction/reflow/keyboard checks and corrected peer findings |
| Data engineer | [Assessment](roles/data-engineer-assessment.md) | [Final engineering peer review](roles/engineering-peer-review.md), extraction/security/export/identity spikes |
| Church member | [Assessment and independent peer review](roles/church-member-assessment.md) | Church selection → verification → enrollment → reader → share/cancel tasks and image inspection |

The contributor, engineer and member raised concrete corrections: wrong church after routing, no primary reading destination, sharing cancel losing reading context, missing public-copy disclosure, unapproved deck source, inconsistent source counts, actions below the fold, and a block list that initially did not drive the reading preview. UX corrected those; independent follow-up checks distinguish the corrected research behavior from unimplemented backend/provider work.

## What is complete and what is not

Research, source inspection, the named local tests, rendered mockups, architectural proposals and cross-review are complete. [Validation](VALIDATION.md) separates actual results from future gates. Live SMS/People/YouTube account integration, media generation/storage/publication, native social-app posting, production fixes and real-human usability remain unverified.

The next decision is **which implementation phase to authorize**, not whether to deploy this storyboard. No build prompt or application rollout is executed by this research. The previous accepted application checks and the separate 1.2.15 release status are not reopened.
