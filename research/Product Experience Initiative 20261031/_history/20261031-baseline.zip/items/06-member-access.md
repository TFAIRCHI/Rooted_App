# 6. Phone-oriented member access, church QR and Planning Center

**Recommendation:** preserve the preferred phone-first destination, but separate it from the immediately useful QR routing improvement. A church QR can route to today’s verified login now; true phone-first sign-in needs an identity architecture decision and live delivery/recovery testing.

## Preferred future experience

Scan a church/study QR or choose a church → enter phone with country → verify a one-time code → confirm name when needed → one clearly labeled church-member join/continue action under that church’s policy → open the intended reading page.

The phone number is a convenient entry/contact identifier, not the database’s permanent person ID. Use a durable internal principal and verified credential mappings so changed/recycled numbers do not replace a person or inherit another account. Name entry personalizes the experience; it cannot prove identity or choose another household member’s account.

## Current constraint and options

Microsoft’s current [External ID customer FAQ](https://learn.microsoft.com/en-us/entra/external-id/customers/faq-customers) states that SMS is not a first authentication factor for external customer tenants. Existing Rooted sessions rely on verified OIDC claims and separate member/contributor assurance. The current Twilio integration sends outbound messages; it is not an OTP identity issuer.

| Path | Benefit / constraint | Decision |
|---|---|---|
| QR + current verified login | Improves church routing/return path with less architectural change; does not deliver phone-first login | Near-term access improvement |
| Managed phone-capable customer identity provider through OIDC | Delegates credential/challenge operations; still needs trusted provider/account linking, member session and recovery work | Evaluate as preferred phone-first production route |
| Narrow Verify-backed member identity issuer | Can provide phone OTP but makes Rooted responsible for issuer/session/linking/abuse/recovery boundaries | Alternative only after architecture/security/operational review |
| Phone/name form without proof | Cannot authenticate or safely associate accounts | Reject |

Neither phone option should weaken or merge contributor/admin MFA and authorization. A member credential cannot be promoted to staff merely because the same phone/name appears in a directory.

## Enrollment must be a separate policy

A QR is shareable routing information. It does not prove formal church membership, authorize a staff role, or establish SMS marketing consent. Give each church a member-space policy: open self-enrollment after verification, approval-required joining, or invitation-only joining. Make the result visible: Joined, Pending approval, or Invitation needed. For an open church, one clear continue/join action can complete enrollment automatically after verification; avoid an unnecessary second registration form.

Resolve QR destination/policy on the server and preserve it through verification/retries. A multi-church account should land in the QR’s church after an explicit join/continue action, not silently lose another membership. Keep the church’s name visible before and after login. Incorrect, expired or revoked QR links need a recoverable state.

## Identity and recovery cases

- Existing account: use existing credentials or a deliberate verified linking flow; no duplicate account or automatic merge by phone/name.
- Shared household phone: do not offer a list of private people and let a name choose identity. Offer another supported credential or church-assisted recovery.
- Changed/recycled number: do not restore historical account/staff authority solely from current phone possession; define verified recovery and old-session revocation.
- Missing/delayed/expired SMS or unsupported phone/country: preserve church/return context, show honest retry timing and a real alternate access path.
- Shared browser: show who is signed in before joining and allow account switching. Persist reading sessions deliberately; do not promise indefinite safety on shared devices.
- Phone verification, member enrollment, optional reminders and directory association are separate purposes. Reminder opt-in stays off by default in the proposed flow.

These cases are product requirements, not a generic warning checklist: each can otherwise put a member in the wrong church/account or prevent reading.

## Planning Center later

The existing adapter uses the **Publishing** scope and an allowlist of Publishing routes. People is a separate product scope under Planning Center’s [authentication model](https://api.planningcenteronline.com/docs/overview/authentication). Do not describe People sync as already connected.

Future path: church administrator authorizes People access → scoped background sync reads permitted person/phone records → normalize and stage candidate links → authorized reconciliation confirms identity/account association → retain organization/person IDs and source timestamps. A directory match is not login proof, public profile permission, member reminder consent or a staff capability grant. Handle duplicate/shared/missing numbers, inactive people, changes and revoked authorization. Do not expose a private directory lookup to an unverified phone form.

## Cost and feasibility gates

Use verification/sent-message volume rather than church size alone. Engineering’s illustrative US scenario of 1,000 successful verifications and 1,200 SMS sends is approximately **$59.96** at checked Twilio inputs, before additional fees/provider/identity costs. It is not a quote or existing Azure-spend estimate. The full formula and dated [pricing source](https://www.twilio.com/en-us/verify/pricing) are in [engineering architecture](../architecture/technical-feasibility.md). Persistent return sessions and deliberate resend controls affect the volume; no SMS was sent in research.

Test a chosen provider with owned test identities, valid/expired/replayed codes, resend/attempt budgets, international formatting, household/number-change recovery and issuer/subject/tenant validation. Then test three church-enrollment policies, duplicate requests, cross-church denial and real-device delivery. A synthetic formatting/ambiguity check cannot establish that a real person belongs to a church or that OTP delivery works.

**Feasibility:** QR routing is supported by the existing route/auth foundation and research flow tests. True phone-first login is conditional on provider/identity-linking work; it is not an Entra configuration toggle. Planning Center People remains a future separately authorized integration.

**Mockups:** [church QR](../mockups/captures/18-church-qr.png), [phone entry](../mockups/captures/19-phone-welcome.png), [code](../mockups/captures/20-phone-verification.png), [church choice](../mockups/captures/23-phone-church-choice.png), [join](../mockups/captures/24-phone-enrollment.png), [pending](../mockups/captures/25-phone-pending.png), [identity ambiguity](../mockups/captures/26-phone-identity-conflict.png).
