# 3. A useful, genuine CoWriter demonstration

**Recommendation:** lead with a short, captioned recording of the actual current application, with a chaptered read-only walkthrough beside it. Show a complete useful outcome, including a human correction and a saved editable draft. Avoid an open public AI sandbox for the first release.

The current homepage example is an illustrative canned exchange. It does not show the contributor supplying context, refining direction, confirming a day, saving the result or handing it to review. A better demonstration answers “What work will this save my church, and who stays responsible?”

## Options

| Option | Value and feasibility | Recommendation |
|---|---|---|
| Actual recorded application walkthrough | Captures a real usable result; no AI cost or account requirement per viewer; can include captions and transcript | First release |
| Guided replay using captured real steps/output | Visitors can inspect the source, question, plan and result at their own pace; must be labeled recorded example | Pair with recording or use as a clear accessible fallback |
| Unauthenticated live model playground | Cost, abuse, privacy, doctrinal misuse, latency and quota pressure; approval/publishing cannot be exposed | Defer until a separately designed bounded demonstration service exists |

A recorded example is not dishonest if it is explicitly recorded. A future concept or fixture response should not be represented as live model output. The research storyboard labels its player as a concept and sends no AI request. No genuine new product video was recorded or paid model call made in this initiative.

## Recording brief: source → useful result

Proposed duration is about 75–100 seconds, subject to a trial recording; it is not measured here.

| Chapter | Actual action to record | Value made visible |
|---|---|---|
| 1. Bring the message | Paste a short fictional, rights-cleared sermon outline using today’s supported reviewed-text path | The church supplies the teaching, not a generic prompt |
| 2. Clarify the direction | Ask for a small set of studies; show CoWriter asking/confirming passage, audience and dates | It collaborates rather than guessing |
| 3. Make one correction | Change the emphasis or audience and show the updated plan | The contributor controls the result |
| 4. Confirm one day | Review the teaching basis and confirm that day | Generation is deliberate and bounded |
| 5. Save and inspect | Open the actual saved editable draft, with revision/date and relevant study sections | There is a practical artifact, not only a chat bubble |
| 6. Hand off | Show review assignment and an illustrative member-reading destination; do not bypass approval | Preparation and publication remain separate |

Do not show future DOCX/YouTube/Studio actions as current product capability before those are implemented. If waiting is shortened in editing, label it as shortened; do not imply measured instant generation. Keep the actual sample source and generated output available for comparison. Show model/output variability without promises that every request produces the same wording.

## Homepage placement

Replace the passive chat vignette with a clear poster and **Watch a study take shape**, duration, short outcome statement, transcript and chapter controls. Keep text describing the practical result visible without playing. No autoplay sound, no login, no visitor model request and no production account details in the recording. A separate “Try the sample reading experience” path is useful for members.

W3C’s [media accessibility guidance](https://www.w3.org/WAI/media/av/) informs captions, transcript, keyboard controls and alternatives when important visual information is not conveyed by audio. Provide a fast poster; load the recording on intent, with responsive assets and player failure fallback. A video must not undo the compact homepage performance goal.

## Recording and validation plan

1. Use an isolated fictional church/study and approved recording script. No real directory, private requests, credentials, provider keys or invitation links may appear.
2. Choose whether the recording uses a real provider generation or explicitly labeled fixture replay. A real-generation recording needs an authorized budget/model/environment, output review and usage record; none was invoked here.
3. Capture the actual browser actions and saved result. Keep an evidence note distinguishing cuts, replay and true product operations.
4. Record narration/captions/transcript; test keyboard playback, mute/pause/scrub, loading failure, phone reflow and reduced motion.
5. Ask a small real pilot group to explain the workflow after watching: what the church supplies, what is saved, who confirms/reviews, and whether the example is live. This future comprehension check is not replaced by agent-role feedback.

**Feasibility:** recording an existing working workflow and hosting a controlled video is a credible near-term path, but no final recording, player integration, encoding/hosting performance or real-person comprehension test was completed here. An open public live-AI demo is a separate conditional product, not the recommended default.

**Mockup:** [homepage player/walkthrough concept](../mockups/captures/12-homepage-demo.png), [phone treatment](../mockups/captures/33-mobile-demo.png).
