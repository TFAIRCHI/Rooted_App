# 5. A separate Studio Creator and immersive study

**Recommendation:** make Studio Creator a distinct composition task alongside the verbal CoWriter. Begin with structured, reorderable study blocks and deterministic diagrams/charts/images, using one renderer for preview and reading. Add AI visual proposals and rights-cleared video only after that foundation is real.

## The separation

| CoWriter | Studio Creator |
|---|---|
| Passage, teaching basis, audience, verbal plan, study sections, questions and application | Visual sequence, layout, images, diagrams, verified-data charts, optional video, captions and alternatives |
| Proposes words; contributor confirms and edits | Proposes visual candidates; contributor selects/attaches and reviews |
| Cannot approve or publish | Cannot approve or publish |
| Shares the source/revision foundation | Shares the source/revision foundation, plus versioned media assets |

There should not be a hidden second AI system rewriting the teaching when the creator asks for a picture. Text changes from Studio must be explicit proposed text edits, reviewed as teaching changes.

## What exists today

The current content contract is strict and text-based. Existing toolbar actions can insert Markdown-like text, and local file previews can use browser object URLs; those are not persistent, approved media blocks. The member reader renders text into fixed sections and includes some template/fallback prose. Engineering and member source review agree that the editor, preview, approved payload and member reader need a shared/versioned rendering contract before richer composition can be called complete.

Do not hide new JSON inside `body` or silently rewrite old approved payloads/hashes. Introduce a versioned contract and legacy adapter deliberately. See [engineering architecture](../architecture/technical-feasibility.md) and [member findings](../roles/church-member-assessment.md).

## First useful block model

Stable block IDs with explicit order: opening/body, Scripture/reference, reflection/application/question, prayer, image, diagram/chart, and supported video. Each informative media block carries an accessible equivalent, source/rights information and immutable asset version. Reorder changes visible, keyboard, screen-reader and narration order together.

The creator works with a block outline, selected canvas and property inspector. **Move up/down** is available beside drag handles. A full reading preview shows the precise saved or unsaved revision; it is not an unrelated phone screenshot. A published member continues seeing the approved snapshot until a new revision is reviewed and published.

An AI image candidate is not immediately attached or approved. Keep the generation request/output, usage, selected asset and exact crop/alt text under version control. For Scripture or study quotes on images, render verified text deterministically over a background rather than trusting generated lettering. For charts, require real structured values/units and a source; an AI guess is not data. Label explanatory diagrams as illustrative models rather than empirical findings.

## Video path

Support approved embedded/owned clips with visible duration, controls, captions/transcript and a readable alternative. Playback remains optional. Do not imply that the Studio can legally download/trim any YouTube video. A church-owned original clip can later use an authorized upload/transcode pipeline; that is separate from an embedded reference and needs storage, processing limits and provider/codec/device testing.

AI video generation is a later conditional capability, not the first Studio release: model availability, rights, moderation, cost, latency and output quality were not tested. A useful editor can deliver diagrams, layouts and approved still images before expensive video generation.

## Architecture and invalidation

Source versions → text revision + ordered visual blocks → asynchronous media/rendition jobs → contributor selection → exact combined preview → independent approval → immutable publication snapshot.

Use private object storage for drafts, tenant-scoped metadata, bounded signed access, safe media URLs and asynchronous jobs. Reuse established idempotency/lease/accounting patterns, but do not assume the current text worker or text-only model is already an image/video service. Media assets need processing state, cancellation/retry, hashes and budget accounting. A crop, diagram data change, block reorder, caption or informative alternative may change what is being taught and must invalidate the relevant approval.

The same block renderer should drive Studio’s immersive preview and the member reader. Make template wording/version explicit; do not add unseen fallback teaching or substitute a passage quotation for an unrelated reference. Existing approved legacy studies retain a defined renderer rather than being reinterpreted silently.

## Evidence and next gates

The research prototype now truly shares its fictional six-block renderer/order between Studio preview and member-rendition preview. Engineering independently verified a reordered block sequence. That is a browser-concept proof, not durable application save, approval or publication parity.

Before implementation is accepted, save/reload/review/publish a mixed block study and compare exact content/order/assets in all renderers. Test v1 legacy reading, invalid/unknown blocks, tenant asset access, stale generation results, changed media after approval, text alternatives, charts without images, blocked video, reduced motion, narration order and keyboard-only reordering. Generated media must have a separately tested model/provider and bounded usage policy.

**Feasibility:** a staged structured-editor product is credible; it is substantial schema/rendering/media work. The existing toolbar is not proof it already works. Production visual generation, durable media, published rendering and video delivery remain unverified.

**Mockups:** [diagram canvas](../mockups/captures/13-studio-diagram.png), [chart](../mockups/captures/14-studio-chart.png), [video empty state](../mockups/captures/15-studio-video-empty.png), [immersive preview](../mockups/captures/16-immersive-preview.png), [member rendition](../mockups/captures/28-member-reading.png).
