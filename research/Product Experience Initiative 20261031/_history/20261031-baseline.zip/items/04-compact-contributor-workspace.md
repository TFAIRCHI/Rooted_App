# 4. Less scrolling for contributors and administrators

**Recommendation:** organize one study around explicit tasks—Overview, Sources, CoWriter, Studio Creator, Share deck and Review—with persistent study/revision/save/review context. Use an in-page side inspector and deliberate full preview. Do not make a separate browser pop-out or a literal no-scroll canvas the primary workflow.

## Design choices

| Pattern | Good use | Limitation / decision |
|---|---|---|
| Task navigation | Stable place for each kind of work; direct links and Back/Forward restore context | Must preserve unsaved edits, selected study and return target; not decorative tabs over one giant page |
| Split view | Selected block or review thread beside its context | Collapse secondary pane at narrow widths; avoid three tiny columns on phones |
| In-page drawer/inspector | Properties, source details, a focused review note | Do not hide unresolved change requests or required errors inside an optional drawer |
| Full-page immersive preview | Read the exact study without editing chrome | Named exit/focus return; draft/saved/revision status remains honest |
| Modal dialog | Short confirmation or narrowly scoped task | Avoid stacking dialogs over long authoring forms; provide focus containment and Escape/return behavior |
| New browser window / document PiP | Optional later multi-monitor preview | Extra window management/support and popup/user-activation constraints; not a required path |

Chrome documents [Document Picture-in-Picture](https://developer.chrome.com/docs/web-platform/document-picture-in-picture/) as a specific browser capability. It is not a universal solution to contributor scrolling. Use ordinary accessible page/panel controls first; modal behavior should follow [WAI’s dialog pattern](https://www.w3.org/WAI/ARIA/apg/patterns/dialog-modal/).

## Primary layout

Keep a compact context row: church, study/date/time zone, saved revision, saved/dirty/error state and review status. A requested-change summary stays visible across tasks. Place the main next action in an accessible desktop action rail, without covering text or leaving a checkbox at the bottom of a long page. Mobile controls return to natural document flow.

Only the selected task’s material occupies the main work area. Do not repeat the same study heading, source instructions, status explanation and consent block above every section. Detail can grow deliberately; long reading content may still scroll. No body-font shrink, clipped messages or scroll traps to claim “all in one view.”

Root/contributor image review found that the initial concept spent too much vertical space before the task and put Source confirmation/Studio controls below the desktop fold. UX corrected the desktop chrome/action rail and added explicit viewport checks. The final screenshot/test ledger records actual dimensions; a static picture alone is not enough to claim improved task completion.

## Per-page direction

| Area | Compact default | Detail on request |
|---|---|---|
| Dashboard | This week’s readiness, review queue and next work item | Filtered list or specific study |
| Calendar/studies | Chosen week/date, status filters, small selected-study summary | Study workspace rather than every editor expanded inline |
| Sources | Source list, selected extract and include/coverage state | Original source metadata, omitted material, extraction errors |
| CoWriter | Focused conversation and current agreed plan/day | Prior conversation, source citations and usage |
| Studio | Block outline, selected canvas, one inspector | Asset library and full reading preview |
| Review | Pinned unresolved request, revision comparison and chronological conversation | Older cycles with stable pagination/anchors |
| Church settings | Clear sections for identity, member access, integrations and policy | Focused forms with separate save/error status |

This research illustrates the study workspace in detail; dashboard/calendar/settings receive an information-architecture proposal, not a claim that every application page was redesigned or tested.

## Navigation and state architecture

Keep one authoritative draft/save state per study revision. Task switching must not create divergent hidden copies. A URL should be able to restore a supported task and selected study, but the existing safe-continuation allowlist accepts only specific routes/query keys. Any future task route/parameter must be added narrowly with authorization checks; do not relax that guard to allow arbitrary return URLs.

Route transition/reload tests must cover dirty edits, failed save, concurrent revision change, current church, selected block/source, and focus restoration. The browser’s Back button should be useful rather than reopening an unrelated modal stack. Prefer a recoverable save conflict over silently replacing the author’s text.

## Acceptance

- At 1366×768 and 1440×900, the selected task’s primary action, save/revision state and unresolved-request entry are reachable without initial scrolling.
- At 320px/390px and enlarged text, content remains readable with natural vertical growth; the desktop rail cannot obscure it.
- Keyboard users can switch tasks, open/close an inspector, move a block without dragging and return from preview.
- A failed review/history request shows retry/error, never an empty conversation that looks like “no feedback.”
- A real contributor can find the next task, act on a review note and return to the same study with fewer lost-context steps. Time/error improvement needs a future human comparison; no percentage efficiency claim is made from agent review.

**Feasibility:** a compact shell and research interactions are demonstrated. Real route/draft-state integration, full application-page coverage and human task performance remain implementation/pilot gates.

**Mockups:** [workspace overview](../mockups/captures/01-workspace-overview.png), [mobile workspace](../mockups/captures/31-mobile-workspace.png), [review](../mockups/captures/17-review-conversation.png).
