# 1. Study CoWriter context inputs

**Recommendation:** add a reviewed source tray, not a single “attach anything” button. Start with DOCX and pasted text/cells, extend approved-host website extraction and selected XLSX ranges, then add authorized YouTube captions. The same tray makes every source inspectable before it becomes teaching context.

## Current state and evidence

The existing guided workflow accepts reviewed text/TXT and reviewed library sources. Provider-library ingestion already has provenance/rights data and defended network fetching. Source content and approved study revisions have separate ownership and hash/version boundaries. This is a foundation to extend, not evidence that DOCX/XLSX/YouTube integration already exists.

Engineering ran synthetic OpenXML extraction/boundary checks, actual current URL-boundary checks and existing source-fetch security tests. See [engineering validation](../evidence/engineering-validation.md) and [technical proposal](../architecture/technical-feasibility.md). The tests do not validate a production Office parser, antivirus service, live website importer or authorized Google account.

## Input-specific path

| Requested input | First useful experience | Failure/uncertainty that stays visible |
|---|---|---|
| Drag/drop Word | Accept `.docx`, extract headings/paragraphs/tables, preview the selected excerpt with original filename and locators; offer file picker as an equal alternative | Legacy `.doc`, encrypted/macro/embedded content, unsupported relationships, formatting omissions and extraction errors are explained; never pretend all layout/comments/images were understood |
| Paste website URL | Fetch only allowed public HTTPS hosts through the existing defended fetch foundation; show captured text, URL/time, source anchors and exclusions | Login/paywall/script-only pages or disallowed redirects/hosts use a paste-text fallback; no browser cookies or open-ended crawler |
| Paste YouTube URL | Show reference/embed metadata, then authorized caption-track selection when available; otherwise ask for an authorized uploaded/pasted transcript | A link alone is not a transcript. The official download endpoint requires authorized edit access to the video; list metadata is not caption text. See [Google caption download](https://developers.google.com/youtube/v3/docs/captions/download) |
| Excel upload or pasted cells | Support `.xlsx` sheet/range selection and a separate pasted-table/TSV path; show headings, cell addresses, date interpretation and selected rows before inclusion | Distinguish formula expressions from cached values; missing/stale results are uncertain, not recalculated truth. Do not execute macros/formulas/external links. Legacy/locked/complex workbooks need an honest unsupported state |

“Paste an Excel file” can mean pasting selected cells or uploading the workbook; the UX should offer both deliberately. Clipboard file support varies, so file picker/drag-drop plus paste-table is clearer than depending on a binary clipboard path.

## Proposed flow

Choose input → capture/extract → inspect source and coverage → select/exclude content → confirm permission and reviewed selection → immutable source version → include selected spans in CoWriter → clarify teaching direction → draft with source references → human confirmation/review.

The preview shows **Not included**, **Ready for review**, **Reviewed**, **Included in this request**, or **Failed** separately. Extraction success is not contributor review; source review is not study approval. Deselecting a source changes the next request, not the already saved approved study. Replacing a document creates a new source version.

Current request limits mean that accepting a file is not permission to send its entire contents to a model. Show selected coverage/omissions and keep requests within budget. Begin with chosen excerpts; add retrieval/indexing only when actual source volume warrants it. Tenant/private scope filtering must happen before ranking.

## Smallest successful release

1. DOCX + existing text input, bounded extraction, selection/provenance and review gate.
2. Website text from explicitly approved hosts; pasted cells and selected XLSX ranges with cached-value/date warnings.
3. Church-authorized YouTube caption connection and transcript fallback. Keep reference-only links useful before that connection exists.

Do not use unauthorized audiovisual downloading as a shortcut. Google’s [developer policies](https://developers.google.com/youtube/terms/developer-policies) restrict downloading/caching audiovisual content without the required approval; a separate rights-cleared original-media transcription path is its own feature.

## Acceptance before calling the integration feasible

- Real production-candidate parser tests preserve paragraphs/table/cell order and identify unsupported content; malformed/oversized/archive-traversal/external-relationship cases fail safely.
- A fresh conversation can cite a Word paragraph, webpage capture, caption timestamp and Excel range from the exact reviewed version.
- Too-large input produces selection/coverage guidance, not silent truncation or an unexpectedly expensive request.
- Private sources do not appear in another account/church or a public deck. Removing rights blocks future use without rewriting past audit history.
- A failed extraction/retry cannot duplicate sources, consume AI tokens unexpectedly, or mark unread material reviewed.
- YouTube is tested with an owned/authorized video, missing captions, revoked permission and quota failure before marketing “paste a link” as automatic transcript access.

**Feasibility:** bounded text extraction and provenance are supported by isolated tests. Full integrations remain conditional on maintained parser selection, real-host/channel tests, storage/scanning, access controls and budget validation.

**Mockups:** [Word review](../mockups/captures/02-source-word-review.png), [website](../mockups/captures/03-source-website-review.png), [YouTube](../mockups/captures/04-source-youtube-review.png), [Excel](../mockups/captures/05-source-excel-review.png), [empty/error](../mockups/captures/07-source-error.png).
