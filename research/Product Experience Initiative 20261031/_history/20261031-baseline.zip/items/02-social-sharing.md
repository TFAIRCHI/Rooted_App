# 2. Branded social decks and member choice

**Recommendation:** publish a separately approved **public excerpt deck** from a precise approved study version. The church prepares it; the member previews and chooses whether/what to share. Start with downloadable images and captions, then add native device sharing where supported. Direct automatic posting is not needed for the initial value.

## Experience and ownership

Contributor prepares Scripture/quote/diagram/chart cards → checks source and wording → previews church + Rooted branding → submits the exact deck rendition → authorized reviewer approves public export → church makes it available on the published study → member chooses card(s), previews what leaves the app and downloads/shares.

The church’s name/logo/colors lead; Rooted appears consistently in a secondary platform credit. Provide accessible contrast and a small controlled template family. A church brand change must not silently alter an already approved exported card. Keep both study and brand/template versions pinned.

| Card | Content rule | Helpful alternative |
|---|---|---|
| Scripture | Exact reviewed wording, reference and translation; correct rights/attribution for public visual use | Copyable text and accessible caption |
| Study quote | Exact excerpt or separately reviewed adaptation, with the study context retained | Full approved caption plus safe destination link |
| Diagram/image | Clarify a teaching idea; distinguish illustrative content from evidence | Meaningful description/alt text |
| Chart | Verified underlying data, units, labels and source; no invented statistics from prose | Data table/description with the export |
| Multiple cards | Numbered ordered set, individual preview/selection, clear public destination | Individual image download if target app rejects several files |

## Public sharing without exposing private reading

A members-only study can have an intentionally public excerpt without making the complete study public. Use a dedicated deck/download/public-landing resource with a separate audience/approval policy. The link should clearly say whether the recipient can read the study, must sign in, or can only view the excerpt. Never export reader screenshots containing names, reactions, private discussion or prayer requests.

Member actions: **Preview → Select → Share or download**. Reading/completion never requires sharing or connecting a social account. Cancel returns to the same reading position. A public-copy notice explains that downloaded or reshared copies can travel beyond the church and cannot be recalled. Withdrawal can stop future delivery from Rooted; it cannot retrieve already downloaded images.

## Export and distribution choices

| Option | Assessment |
|---|---|
| Deterministic PNG template export + text caption/link | Recommended baseline; consistent, reviewable and useful without social-platform credentials |
| Native device share sheet | Progressive enhancement after file-capability checks; installed targets and multi-file/order/caption behavior need real-device testing |
| PDF/ZIP deck downloads | Useful later; not established by a successful single-image export |
| Direct Meta/other platform posting integration | Later optional scope with account authorization, platform review, permissions and failure/retry behavior; not required for member-controlled sharing |

The [W3C Web Share specification](https://www.w3.org/TR/web-share/) requires user-agent support and user activation for sharing. A resolved share operation does not prove that a social post appeared. Keep Download/Copy caption as real fallbacks.

Deterministic synthetic PNG exports were tested: engineering produced portrait assets and UX produced square cards. These prove local raster export, not social-app acceptance or a production deck service. The storyboard’s file downloads and selection are research controls, not proof of native OS posting.

## Approval, rights and stale states

Study approval alone does not approve a shortened quote, crop, generated image or new public audience. A deck approval pins study revision/hash, deck text/order, asset/crop hashes, renderer version and brand/template versions. A current changes-requested draft must not be presented as approved. The corrected mockup uses a prior approved study snapshot distinctly from the current draft.

A changed underlying study/asset/rendition marks the deck stale. Existing approved public content may remain available only under an explicit policy for that earlier version; otherwise withdraw it until review. Show that choice honestly, not a generic green “Approved” label. See the [engineering permission proposal](../roles/engineering-peer-review.md).

Scripture permissions are edition/format/use-specific. Do not assume permission for an in-app study automatically covers public visual exports or a software product. Preserve required translation notices and obtain any necessary permissions against the chosen use. Primary references: [Crossway permissions](https://www.crossway.org/permissions/), [Biblica permissions](https://www.biblica.com/permissions/). This initiative does not select a licensed Bible-text provider or grant rights.

## Exit tests

Save/reload an exact approved deck; invalidate on study/text/crop/brand change; reject unauthorized tenant/member/draft access; confirm no private data in raster/caption/link; test clipping/contrast/long passages; test individual and multi-card selection plus cancel/recovery. Run iOS Safari/Android Chrome with actual intended apps and verify what the recipient sees. Do not require public posting to test fallback downloads.

**Feasibility:** local image export is demonstrated; a useful deterministic deck product is conditional on the rendition/approval/access model. Native sharing and platform posting are not live-verified.

**Mockups:** [authoring](../mockups/captures/09-deck-author.png), [approval](../mockups/captures/10-deck-approval.png), [stale deck](../mockups/captures/11-deck-stale.png), [member choice](../mockups/captures/29-member-share.png).
