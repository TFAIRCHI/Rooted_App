import {chromium} from '@playwright/test';
import {writeFile,mkdir} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
export async function renderDeckExports(page){
 await mkdir(path.join(root,'exports'),{recursive:true});
 await page.setViewportSize({width:1440,height:1200});await page.goto('http://127.0.0.1:3091/?view=deck');
 await page.addStyleTag({content:'#deck-export{position:fixed!important;left:0!important;top:0!important;z-index:999!important;margin:0!important}.deck-slide{width:1080px!important;height:1080px!important;max-height:none!important;max-width:none!important;padding:90px!important;aspect-ratio:1!important}.deck-slide h2{font-size:114px!important;max-width:820px!important;margin-top:100px!important}.deck-slide p{font-size:35px!important;max-width:720px!important;margin-top:50px!important}.deck-slide .deck-logo{font-size:35px!important;padding-bottom:35px!important}.deck-slide .co-brand{font-size:28px!important}.deck-slide .co-brand b{font-size:52px!important}.deck-slide:after{font-size:380px!important;top:230px!important;right:40px!important}'});
 for(let i=1;i<=4;i++){
  // The original controls remain behind the fixed export rendition.
  await page.locator(`[data-slide="${i}"]`).dispatchEvent('click');
  await page.locator('#deck-export').screenshot({path:path.join(root,'exports',`grace-rooted-card-${i}.png`)});
 }
 await writeFile(path.join(root,'exports','accessible-caption.txt'),'Fictional research design sample. Grace Community Church + Rooted. Four-card public invitation: A little time, deeper roots; remain in Christ, not in your own strength; what helps you stay close? Make room for his words. Passage: John 15:1–8. Public invitation URL is illustrative: rooted.example/grace/abide. No private reflection or member information is included. These rendered 1080×1080 PNGs are research artifacts, not approved production exports.');
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const browser=await chromium.launch({channel:'msedge',headless:true});const page=await browser.newPage();await renderDeckExports(page);await browser.close();console.log('Rendered four exact 1080×1080 research deck cards.');
}
